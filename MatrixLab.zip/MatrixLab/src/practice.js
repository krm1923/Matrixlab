import { guided,recall,persist } from "./guided.js";
import { exams, examSource, topics, extraCheckpoints } from "./exams.js";
import { parse,add as addQ,mul,binary } from "./math.js";
export function practice(language, loadMatrix) {
  const nav = document.getElementById("studyNav");
  const panel = document.getElementById("practice");
  const workspace = document.getElementById("workspace");
  let active = false,
    filter = "",
    position = 0,
    revealHint = false,
    revealAnswer = false,
    draft = "",
    verdict = "",
    finished = new Set();
  const local = (en, tr) => (language() === "tr" ? tr : en);
  try {
    finished = new Set(
      JSON.parse(localStorage.getItem("matrixlab-exam-completed")) || [],
    );
  } catch {}
  let section="study", reviewKeys=[], statuses=recall("ml-exam-status",{}), reviewing=false;
  const lessonPanel=document.getElementById("guided"),renderLesson=guided(lessonPanel,local,loadMatrix);
  function saveState(key,status){statuses[key]=status;persist("ml-exam-status",statuses);if(status!=="correct"){finished.delete(key);persist("matrixlab-exam-completed",[...finished])}}
  function add(tag, parent, label) {
    const e = document.createElement(tag);
    if (label) e.textContent = label;
    parent.append(e);
    return e;
  }
  function button(parent, label, click) {
    const b = add("button", parent, label);
    b.onclick = click;
    if(parent===nav){
      let origin;
      b.onpointerdown=e=>{origin=[e.clientX,e.clientY]};
      b.onpointercancel=()=>{origin=null};
      b.onpointerup=e=>{
        if(e.pointerType==="touch" && origin && Math.hypot(e.clientX-origin[0],e.clientY-origin[1])<10){e.preventDefault();click()}
        origin=null;
      };
    }
    return b;
  }
  function begin() {
    position = 0;
    clearCard();
  }
  function clearCard() {
    revealHint = false;
    revealAnswer = false;
    draft = "";
    verdict = "";
  }
  function open(value) {
    section=value?"exam":"matrix";
    active = value;
    render();
    window.scrollTo(0, 0);
  }
  function render() {
    workspace.hidden = section !== "matrix";
    lessonPanel.hidden=section!=="study";
    panel.hidden = !active;
    nav.replaceChildren();
    button(nav,local("Study","Çalış"),()=>{section="study";active=false;render()}).setAttribute("aria-pressed",String(section==="study"));
    button(nav, local("Matrix workspace", "Matris çalışma alanı"), () =>
      open(false),
    ).setAttribute("aria-pressed", String(section==="matrix"));
    button(nav, local("Exam practice", "Final çalışması"), () =>
      open(true),
    ).setAttribute("aria-pressed", String(active));
    if(section==="study")renderLesson();
    if (!active) return;
    panel.replaceChildren();
    const group = add("section", panel);
    group.className = "practice";
    add("h1", group, local("Final question bank", "Final soru havuzu"));
    const row = add("div", group);
    row.className = "bar practice-filters";
    const select = (label, values, current, changed) => {
      const input = add("select", add("label", row, label));
      for (const [key, title] of values) {
        const option = add("option", input, title);
        option.value = key;
      }
      input.value = current;
      input.onchange = () => {
        changed(input.value);
        begin();
        render();
      };
    };
    select(
      local("Topic", "Konu"),
      [
        ["", local("All topics", "Tüm konular")],
        ...topics.map(([en, tr], i) => [String(i), local(en, tr)]),
      ],
      filter,
      (x) => (filter = x),
    );
    button(row,reviewing?local("All exam cards","Tüm final kartları"):local("Review missed cards","Tekrar listesi"),()=>{reviewing=!reviewing;reviewKeys=Object.keys(statuses).filter(key=>statuses[key]==="review");begin();render()});
    const cards = ["2025","2023","2022A","2022B","2019B","2017A"]
      .flatMap(year => exams[year].map((card,index) => ({year,card,index})))
      .filter(({card}) => filter === "" || String(card.topic) === filter)
      .filter(({year,index}) => !reviewing || reviewKeys.includes(year + ":" + index));
    if(!cards[position])position=Math.max(0,cards.length-1);
    if (!cards.length) {
      add(
        "p",
        group,
        local(
          "No matching cards for these filters.",
          "Bu seçimlere uygun kart yok.",
        ),
      );
      return;
    }
    const { card, year, index } = cards[position],
      key = year + ":" + index;
    add(
      "p",
      group,
      local("Solved", "Doğrulanan") +
        " " +
        cards.filter(({ year, index: i }) => finished.has(year + ":" + i)).length +
        " / " +
        cards.length,
    );
    const cardSection = add("article", group);
    cardSection.className = "exam-card";
    const identity =
      index < 6
        ? local("Problem", "Problem") + " " + (index + 1)
        : local("Question", "Kısa soru") + " " + (index - 5);
    add("h2", cardSection, identity + " · " + local(...topics[card.topic]));
    const meta=examSource(year,index);
    add("small",cardSection,meta.file+" · "+identity+" · "+local("p. ","s. ")+meta.page+" · "+local("Final","Final")+" · "+(index<6?local("Multi-step","Çok adımlı"):local("Short","Kısa")));
    add("p", cardSection, local(...card.question));
    if (card.matrix)
      add(
        "pre",
        cardSection,
        (card.param??card.matrix).map((row) => row.join("   ")).join("\n"),
      );
    if (year === "2023" && index === 2)
      add("pre", cardSection, "B = [0 0 3 7; 0 0 2 5; 2 3 0 0; 3 4 0 0]");
    if (year === "2025" && index === 4)
      add(
        "small",
        cardSection,
        local(
          "The matrix preview uses t = −2.",
          "Matris önizlemesinde t = −2 kullanılıyor.",
        ),
      );
    const checkpoints = {
      2023: ["t", "t", "det(BᵀABA)", "λ max", "(Pᵥw)₁", "min", "t"],
      2025: ["t", "dim V", "s", "(φ²(1,0))₁", "excluded t", "min"],
    };
    const checkpoint =
      index === 4 && year === "2025"
        ? local("Excluded t", "Hariç tutulan t")
        : (checkpoints[year] ?? extraCheckpoints[year])[index];
    const controls = add("div", cardSection);
    controls.className = "bar practice-filters";
    function check(value) {
      draft = value;
      let correct = false,formatError=false;
      if (typeof card.answer === "boolean")
        correct = value === String(card.answer);
      else {
        try {
          correct = value.trim() !== "" && parse(value) === card.answer;
        } catch {formatError=true}
      }
      if(card.answer===null){
        try{
          const s=value.trim().split(/\s+/).map(parse);
          if(year==="2023"&&index===9)correct=s.length===2&&s.some(x=>x!=="0")&&addQ(s[0],mul("3",s[1]))==="0";
          if(year==="2023"&&index===10)correct=s.length===2&&s[0]==="1"&&!["3","5"].includes(s[1]);
          if(year==="2025"&&index===6&&s.length===4){const a=[s.slice(0,2),s.slice(2)],square=binary(a,a,"product");correct=(s[1]!=="0"||s[2]!=="0")&&square.every((r,i)=>r.every((v,j)=>addQ(v,i===j?"2":"0")===mul("3",a[i][j])))}
          if(year==="2025"&&index===8)correct=s.length===1&&s[0]==="3";
        }catch{formatError=true}
      }
      saveState(key,correct?"correct":"review");
      verdict = correct ? "correct" : formatError?"format":"retry";
      if (correct) {
        finished.add(key);
        try {
          localStorage.setItem(
            "matrixlab-exam-completed",
            JSON.stringify([...finished]),
          );
        } catch {}
      }
      render();
    }
    const extraLabel=year==="2023"?(index===9?local("Kernel direction before normalization (x y)","Normalleştirmeden önce çekirdek yönü (x y)"):local("Third solution (x y)","Üçüncü çözüm (x y)")):(index===6?local("Four entries, row by row","Dört eleman, satır sırasıyla"):local("Squared length","Uzunluğun karesi"));
    if (typeof card.answer === "string"||card.answer===null) {
      const label = add(
        "label",
        controls,
        local("Check one part", "Bir adımı kontrol et") +
          " · " +
          (card.answer===null?extraLabel:checkpoint || ""),
      );
      const input = add("input", label);
      input.value = draft;
      input.inputMode = "decimal";
      if(card.answer===null) input.dataset.sequence="true";
      input.autocomplete = "off";
      input.oninput = () => {draft = input.value;if(!statuses[key]&&!finished.has(key))saveState(key,"practicing")};
      input.onkeydown = (e) => {
        if (e.key === "Enter") check(draft);
      };
      button(controls, local("Check", "Kontrol et"), () => check(draft));
    } else if (typeof card.answer === "boolean") {
      button(controls, local("Yes", "Evet"), () => check("true"));
      button(controls, local("No", "Hayır"), () => check("false"));
    }
    const feedback = add("div", cardSection);
    feedback.setAttribute("aria-live", "polite");
    if (verdict)
      add(
        "p",
        feedback,
        verdict === "correct"
          ? local("Correct.", "Doğru.")
          : verdict==="format"?local("Use numbers or fractions.","Sayı veya kesir kullan."):local(
              "Try again. "+local(...card.hint),
              "Tekrar dene. "+local(...card.hint),
            ),
      );
    const actions = add("div", cardSection);
    actions.className = "bar practice-filters";
    button(
      actions,
      revealHint ? local("Hide hint", "İpucunu gizle") : local("Hint", "İpucu"),
      () => {
        revealHint = !revealHint;
        render();
      },
    );
    button(
      actions,
      revealAnswer
        ? local("Hide solution", "Çözümü gizle")
        : local("Show solution", "Çözümü gör"),
      () => {
        revealAnswer = !revealAnswer;
        render();
      },
    );
    if (card.matrix)
      button(actions, local("Open in MatrixLab", "MatrixLab’de aç"), () =>
        loadMatrix(card),
      );
    if (revealHint) add("p", cardSection, local(...card.hint));
    if (revealAnswer) {
      const solution = add("p", cardSection, local(card.solutionEN||card.solution,card.solutionTR||card.solution));
      solution.className = "result";
    }
    button(actions,local("Mark for review","Tekrara bırak"),()=>{saveState(key,"review");render()});
    button(actions,local("Reset card","Kartı sıfırla"),()=>{saveState(key,"new");clearCard();render()});
    const state=statuses[key]??(finished.has(key)?"correct":"new");
    add("small",cardSection,({review:local("Needs review","Tekrar gerekli"),practicing:local("Practicing","Çalışılıyor"),correct:local("Checkpoint correct","Kontrol adımı doğru"),new:local("Not started","Başlanmadı")})[state]);
    const paging = add("div", group);
    paging.className = "bar practice-filters";
    button(paging, local("Previous", "Önceki"), () => {
      position--;
      clearCard();
      render();
    }).disabled = position === 0;
    add("span", paging, position + 1 + " / " + cards.length);
    button(paging, local("Next", "Sonraki"), () => {
      position++;
      clearCard();
      render();
    }).disabled = position === cards.length - 1;
  }
  return { open, render };
}
