// Canonical rational strings keep snapshots serializable and avoid rounding pivots.
function gcd(a, b) {
  while (b) [a, b] = [b, a % b];
  return a < 0n ? -a : a;
}
function rational(n, d = 1n) {
  if (!d) throw Error("zeroDen");
  const g = gcd(n, d) * (d < 0n ? -1n : 1n);
  n /= g;
  d /= g;
  return d === 1n ? String(n) : n + "/" + d;
}
function parts(x) {
  const [n, d = "1"] = String(x).split("/");
  return [BigInt(n), BigInt(d)];
}
function decimal(s) {
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(s)) throw Error("invalid");
  const digits = (s.split(".")[1] || "").length;
  return rational(BigInt(s.replace(".", "")), 10n ** BigInt(digits));
}
export function parse(raw) {
  const s = String(raw).trim().replaceAll("−", "-").replaceAll(",", ".");
  if (!s) return "0";
  const p = s.split("/").map((x) => x.trim());
  if (p.length > 2) throw Error("invalid");
  return p.length === 1 ? decimal(p[0]) : div(decimal(p[0]), decimal(p[1]));
}
export function add(a, b) {
  const [n, d] = parts(a),
    [m, e] = parts(b);
  return rational(n * e + m * d, d * e);
}
export function mul(a, b) {
  const [n, d] = parts(a),
    [m, e] = parts(b);
  return rational(n * m, d * e);
}
export function div(a, b) {
  const [n, d] = parts(a),
    [m, e] = parts(b);
  return rational(n * e, d * m);
}
export const neg = (a) => mul("-1", a),
  num = (a) => {
    const [n, d] = parts(a);
    return Number(n) / Number(d);
  };
export const matrix = (m, n, f = () => "0") =>
  Array.from({ length: m }, (_, i) =>
    Array.from({ length: n }, (_, j) => f(i, j)),
  );
export const transpose = (a) => a[0].map((_, j) => a.map((r) => r[j]));
export function rowOperation(a, op) {
  const { type, i, j, k } = op,
    b = a.map((r) => r.slice());
  if (type === "swap") {
    if (i === j) throw Error("distinct");
    [b[i], b[j]] = [b[j], b[i]];
  } else if (type === "scale") {
    if (k === "0") throw Error("nonzero");
    b[i] = b[i].map((x) => mul(x, k));
  } else {
    if (i === j) throw Error("distinct");
    b[i] = b[i].map((x, c) => add(x, mul(k, b[j][c])));
  }
  return b;
}
export function eliminate(a, reduced = true, n = a[0].length) {
  let b = a.map((r) => r.slice()),
    piv = [],
    steps = [],
    det = "1";
  function apply(op) {
    b = rowOperation(b, op);
    steps.push({ a: b, op });
  }
  for (let col = 0; col < n && piv.length < b.length; col++) {
    const i = piv.length,
      p = b.findIndex((r, j) => j >= i && r[col] !== "0");
    if (p < 0) continue;
    if (p !== i) {
      apply({ type: "swap", i, j: p });
      det = neg(det);
    }
    det = mul(det, b[i][col]);
    piv.push(col);
    for (let j = i + 1; j < b.length; j++)
      if (b[j][col] !== "0")
        apply({ type: "add", i: j, j: i, k: neg(div(b[j][col], b[i][col])) });
  }
  if (reduced)
    for (let i = piv.length - 1; i >= 0; i--) {
      const c = piv[i];
      if (b[i][c] !== "1") apply({ type: "scale", i, k: div("1", b[i][c]) });
      for (let j = 0; j < i; j++)
        if (b[j][c] !== "0")
          apply({ type: "add", i: j, j: i, k: neg(b[j][c]) });
    }
  return {
    a: b,
    piv,
    steps,
    det: a.length === n ? (piv.length === n ? det : "0") : null,
  };
}
export function system(a, v) {
  const n = a[0].length,
    r = eliminate(
      a.map((row, i) => [...row, v[i]]),
      true,
      n,
    );
  const free = Array.from({ length: n }, (_, i) => i).filter(
    (i) => !r.piv.includes(i),
  );
  const none = r.a.slice(r.piv.length).some((row) => row[n] !== "0");
  const base = Array(n).fill("0");
  r.piv.forEach((j, i) => (base[j] = r.a[i][n]));
  const dirs = free.map((f) => {
    const d = Array(n).fill("0");
    d[f] = "1";
    r.piv.forEach((j, i) => (d[j] = neg(r.a[i][f])));
    return d;
  });
  return { none, free, base, dirs, ...r };
}
export function inverse(a) {
  if (a.length !== a[0].length) throw Error("square");
  const n = a.length,
    r = eliminate(
      a.map((row, i) => [
        ...row,
        ...Array.from({ length: n }, (_, j) => (i === j ? "1" : "0")),
      ]),
      true,
      n,
    );
  if (r.piv.length < n) throw Error("singular");
  return r.a.map((r) => r.slice(n));
}
export function binary(a, b, op) {
  if (op === "product") {
    if (a[0].length !== b.length) throw Error("inner");
    return matrix(a.length, b[0].length, (i, j) =>
      a[i].reduce((v, x, k) => add(v, mul(x, b[k][j])), "0"),
    );
  }
  if (a.length !== b.length || a[0].length !== b[0].length) throw Error("same");
  return matrix(a.length, a[0].length, (i, j) =>
    add(a[i][j], op === "minus" ? neg(b[i][j]) : b[i][j]),
  );
}
