import {add,mul,neg,parse} from './math.js';
export const mapFormulas=[
  "φ(x) = (x₁+3x₂−1, 4x₁+2x₂+6)",
  "φ(x) = (x₁+3x₂−x₃, 4x₁+2x₂+6x₃)",
  "φ(x) = (x₁+3x₂−x₃, 4|x₁|+2|x₂|+6|x₃|)",
  "φ(x) = ((x₁+2)²−x₁²−x₃−4, 4x₁+2x₂+6x₃)"
];
export function linearity(which,test,u,v,k){
  function apply([x,y,z]){
    let first=add(add(x,mul('3',y)),neg(z));
    if(which==='a')return [add(add(x,mul('3',y)),'-1'),add(add(mul('4',x),mul('2',y)),'6')];
    if(which==='d')first=add(mul('4',x),neg(z));
    if(which==='c')[x,y,z]=[x,y,z].map(q=>q.replace(/^-/,''));
    return [first,add(add(mul('4',x),mul('2',y)),mul('6',z))];
  }
  const plus=(x,y)=>x.map((a,i)=>add(a,y[i])),scale=(x,k)=>x.map(a=>mul(a,k));
  u=u.map(parse);v=v.map(parse);k=parse(k);
  let left,right;
  if(test==='zero'){left=apply(['0','0','0']);right=['0','0']}
  else if(test==='scalar'){left=apply(scale(u,k));right=scale(apply(u),k)}
  else{left=apply(plus(u,v));right=plus(apply(u),apply(v))}
  return {left,right,equal:left.every((x,i)=>x===right[i]),linear:['b','d'].includes(which),matrix:which==='b'?[[1,3,-1],[4,2,6]]:[[4,0,-1],[4,2,6]]};
}
