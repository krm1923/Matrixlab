// Coefficients in ascending order. [] denotes the zero polynomial. All
// operations delegate scalar arithmetic to the existing rational kernel.
import {parse,add,mul,div,neg,eliminate} from './math.js';
const trim=p=>{while(p.at(-1)==='0')p.pop();return p};
const plus=(a,b)=>trim(Array.from({length:Math.max(a.length,b.length)},(_,i)=>add(a[i]||'0',b[i]||'0')));
const scale=(p,k)=>trim(p.map(v=>mul(v,k)));
function product(a,b){
  if(!a.length||!b.length)return [];
  const c=Array(a.length+b.length-1).fill('0');
  a.forEach((v,i)=>b.forEach((w,j)=>{c[i+j]=add(c[i+j],mul(v,w))}));return trim(c);
}
function quotient(a,b){
  let r=a.slice();const q=[];
  while(r.length>=b.length){
    const k=r.length-b.length,v=div(r.at(-1),b.at(-1));
    q[k]=v;r=plus(r,[...Array(k).fill('0'),...scale(b,neg(v))]);
  }
  return [Array.from(q,v=>v??'0'),r];
}
function gcd(a,b){while(b.length){[a,b]=[b,quotient(a,b)[1]]}return a.length?scale(a,div('1',a.at(-1))):[]}
const squareFree=p=>quotient(p,gcd(p,p.slice(1).map((v,i)=>mul(String(i+1),v))))[0];
function parseCell(raw,ctx){
  const s=String(raw).replace(/\s/g,'').replaceAll('−','-').replace(/lambda/gi,'λ').replaceAll('²','^2').replaceAll('³','^3');
  if(!/[tsaλ]/.test(s))return trim([parse(s)]);
  const terms=s.match(/[+-]?[^+-]+/g);
  if(!terms||terms.join('')!==s)throw Error('pencilForm');
  let p=[];
  for(const term of terms){
    const m=term.match(/^([+-]?(?:\d+(?:[.,]\d+)?(?:\/\d+)?)?)\*?([tsaλ])(?:\^([1-5]))?$/);
    if(!m){p=plus(p,[parse(term)]);continue}
    if(ctx.symbol&&ctx.symbol!==m[2])throw Error('pencilForm');ctx.symbol=m[2];
    const k=Number(m[3]||1),v=parse(m[1]==='-'?'-1':m[1]==='+'||!m[1]?'1':m[1]);
    p=plus(p,[...Array(k).fill('0'),v]);
  }
  return p;
}
function subsets(n,k,start=0){
  if(k===0)return [[]];
  const out=[];for(let i=start;i<=n-k;i++)for(const tail of subsets(n,k-1,i+1))out.push([i,...tail]);
  return out;
}
export function polyText(p,x){
  let result='';for(let i=p.length-1;i>=0;i--){if(p[i]==='0')continue;
    const sign=p[i].startsWith('-'),abs=sign?p[i].slice(1):p[i];
    result+=(result?(sign?' − ':' + '):(sign?'−':''))+(i&&abs==='1'?'':abs)+(i?x:'')+(i>1?'^'+i:'');
  }return result||'0';
}
function sqrtInt(n){if(n<2n)return n;let x=n,y=(x+1n)/2n;while(y<x){x=y;y=(x+n/x)/2n}return x}
function roots(p,symbol){
  if(p.length===2)return [div(neg(p[0]),p[1])];
  if(p.length===3){
    const [c,b,a]=p,d=add(mul(b,b),neg(mul('4',mul(a,c))));
    if(d.startsWith('-'))return [];
    const [n,e='1']=d.split('/'),u=sqrtInt(BigInt(n)),v=sqrtInt(BigInt(e));
    if(u*u===BigInt(n)&&v*v===BigInt(e)){
      const z=div(String(u),String(v));return [...new Set([z,neg(z)].map(k=>div(add(neg(b),k),mul('2',a))))];
    }
    return ['('+neg(b)+' ± √('+d+')) / ('+mul('2',a)+')'];
  }
  return [symbol+' ∈ {x ∈ ℝ | '+polyText(p,'x')+' = 0}'];
}
export function pencil(input){
  const ctx={},m=input.map(r=>r.map(v=>parseCell(v,ctx))),rows=m.length,cols=m[0].length,symbol=ctx.symbol||'t',cache=new Map();
  function minor(rr,cc){
    if(!rr.length)return ['1'];
    const key=rr.join('')+':'+cc.join('');
    if(cache.has(key))return cache.get(key);
    let d=[];cc.forEach((j,k)=>{const v=m[rr[0]][j];if(v.length){const t=product(v,minor(rr.slice(1),cc.filter(c=>c!==j)));d=plus(d,k%2?scale(t,'-1'):t)}});
    cache.set(key,d);return d;
  }
  const divisors=[['1']];
  for(let k=1;k<=Math.min(rows,cols);k++){
    let g=[];
    outer:for(const rr of subsets(rows,k))for(const cc of subsets(cols,k)){
      g=gcd(g,minor(rr,cc));if(g.length===1)break outer;
    }
    if(!g.length)break;
    divisors.push(squareFree(g));
  }
  const rank=divisors.length-1,cases=[];
  for(let k=0;k<rank;k++){
    // D_k vanishes exactly when rank < k. Remove those smaller-rank roots.
    const p=quotient(divisors[k+1],divisors[k])[0];
    if(p.length>1){const values=roots(p,symbol);if(values.length)cases.push({rank:k,values,poly:p})}
  }
  const det=rows===cols?minor(subsets(rows,rows)[0],subsets(cols,cols)[0]):null;
  const rankAt=x=>eliminate(m.map(r=>r.map(p=>p.reduceRight((v,k)=>add(mul(v,x),k),'0'))),false).piv.length;
  return {symbol,rank,det,cases,rankAt};
}
