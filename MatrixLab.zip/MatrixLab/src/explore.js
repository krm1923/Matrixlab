import {mul, eliminate, matrix} from "./math.js";
export function expansion(a,axis,index) {
  return a.map((_,k)=>{
    const i=axis==='row'?index:k,j=axis==='row'?k:index;
    const minor=a.filter((_,r)=>r!==i).map(row=>row.filter((_,c)=>c!==j));
    const sign=(i+j)%2?'-1':'1',det=minor.length?eliminate(minor,false).det:'1';
    return {i,j,minor,det,sign,term:mul(mul(a[i][j],sign),det)};
  });
}
export const identity=n=>matrix(n,n,(i,j)=>i===j?'1':'0');
