// Paraphrased practice checkpoints from WNE Series B, February 2023 and January 2025.
// Format: topic, question, hint, checked value, worked answer, optional MatrixLab preset.
const p = (
  topic,
  question,
  hint,
  answer,
  solution,
  matrix,
  operation,
  rhs,
) => ({ topic, question, hint, answer, solution, matrix, operation, rhs });
export const topics = [
  ["Linear systems", "Denklem sistemleri"],
  ["Vector spaces", "Vektör uzayları"],
  ["Independence and bases", "Bağımsızlık ve baz"],
  ["Linear transformations", "Doğrusal dönüşümler"],
  ["Composition and coordinates", "Bileşke ve koordinatlar"],
  ["Determinants", "Determinantlar"],
  ["Applications of determinants", "Determinant uygulamaları"],
  ["Endomorphisms", "Endomorfizmalar"],
  ["Orthogonality", "Diklik"],
  ["Simplex", "Simpleks"],
];
export const exams = {
  2023: [
    p(
      2,
      [
        "Find a basis of span{(1,2,7), (2,3,12), (1,4,11)}. For what t is (2,−1,t) in the span? Give its coordinates.",
        "Verilen vektörlerin gerdiği uzayın bazını ve boyutunu bul. (2,−1,t) hangi t için uzayda? Koordinatlarını bul.",
      ],
      [
        "Use the first two pivot columns, then solve for the first two components of the target.",
        "İlk iki pivot sütunu al. Hedefin ilk iki bileşeninden katsayıları bul.",
      ],
      "4",
      "v₃ = 5v₁ − 2v₂. B = (v₁,v₂), dim V = 2.  a + 2b = 2, 2a + 3b = −1 ⇒ (a,b) = (−8,5).  t = 7a + 12b = 4.",
      [
        [1, 2, 1],
        [2, 3, 4],
        [7, 12, 11],
      ],
      "basis",
    ),
    p(
      1,
      [
        "Find a basis and dimension of ker A. Find t such that every vector in ker A satisfies x₁−x₂+tx₃−2x₄=0.",
        "ker A için baz ve boyut bul. Çekirdekteki her vektörün x₁−x₂+tx₃−2x₄=0 denklemini sağladığı t değerini bul.",
      ],
      [
        "Set each free variable to 1 separately, then test both basis vectors in the extra equation.",
        "Her serbest değişkeni ayrı ayrı 1 yap. İki baz vektörünü de ek denklemde dene.",
      ],
      "1",
      "A = [1 1 5 0; 2 3 12 1; −3 13 17 16]. B = {(−3,−2,1,0),(1,−1,0,1)}, dim V = 2. İlk vektör (first vector) ⇒ t − 1 = 0. İkinci (second) ⇒ 0 = 0.",
      [
        [1, 1, 5, 0],
        [2, 3, 12, 1],
        [-3, 13, 17, 16],
      ],
      "solve",
      [0, 0, 0],
    ),
    p(
      5,
      ["Compute det A and det(BᵀABA).", "det A ve det(BᵀABA) değerlerini bul."],
      [
        "Use det(Bᵀ)=det B and multiply determinant factors.",
        "det(Bᵀ)=det B özelliğini kullan ve determinantları çarp.",
      ],
      "4",
      "A = [3 1 1 3; 2 1 4 3; 4 1 2 2; 3 1 3 3]. B = [0 0 3 7; 0 0 2 5; 2 3 0 0; 3 4 0 0]. det A = 2, det B = −1 ⇒ det(BᵀABA) = (2·(−1))² = 4.",
      [
        [3, 1, 1, 3],
        [2, 1, 4, 3],
        [4, 1, 2, 2],
        [3, 1, 3, 3],
      ],
      "det",
    ),
    p(
      7,
      [
        "For φ(x,y)=(2x+y,−2x+5y), find eigenvalues, eigenspace bases and the standard matrix of φ².",
        "Özdeğerleri, özuzay bazlarını ve φ²’nin standart matrisini bul.",
      ],
      [
        "Solve det(A−λI)=0. Multiply A by itself in the standard basis.",
        "det(A−λI)=0 denklemini çöz. Standart matrisi kendisiyle çarp.",
      ],
      "4",
      "λ²−7λ+12=(λ−3)(λ−4). E₃=span{(1,1)}, E₄=span{(1,2)}. A²=[2 7; −14 23].",
      [
        [2, 1],
        [-2, 5],
      ],
      "product",
    ),
    p(
      8,
      [
        "Orthonormalize the plane x−y−z=0 and project (8,1,1) onto it.",
        "x−y−z=0 düzlemi için ortonormal baz bul ve (8,1,1) vektörünü düzleme dik izdüşür.",
      ],
      [
        "Subtract the component along the plane normal (1,−1,−1).",
        "(1,−1,−1) normalindeki bileşeni çıkar.",
      ],
      "6",
      "B = {(1,1,0)/√2,(1,−1,2)/√6}. w·n=6, n·n=3 ⇒ Pᵥw=w−2n=(6,3,3).",
    ),
    p(
      9,
      [
        "Minimize −x₂+4x₄ with x₁+x₂+x₃+x₄=6, 3x₁+2x₂+x₃+x₄=8 and x≥0. Check bases {3,4}, {2,4}, {1,2}, then use simplex.",
        "Verilen eşitlikler ve x≥0 altında −x₂+4x₄’ü minimize et. {3,4}, {2,4}, {1,2} bazlarını dene ve simpleks adımını yap.",
      ],
      [
        "Subtract the first constraint from the second. Start with {2,4}; let x₃ enter.",
        "İkinci denklemden ilkini çıkar. {2,4} ile başla ve x₃’ü baza al.",
      ],
      "-2",
      "{3,4}: det=0. {2,4}: (0,2,0,4) feasible. {1,2}: (−4,10,0,0) infeasible. x₃ enters, x₄ leaves ⇒ (0,2,4,0). 2x₁+x₂=2 ⇒ −x₂+4x₄≥−2.",
      [
        [1, 1, 1, 1],
        [3, 2, 1, 1],
      ],
      "solve",
      [6, 8],
    ),
    p(
      7,
      [
        "For φ(x,y)=(3x−y, tx+2y), find t so (1,1) is an eigenvector, and give λ.",
        "(1,1) özvektör olacak şekilde t ve λ değerlerini bul.",
      ],
      [
        "The two components of φ(1,1) must match.",
        "φ(1,1) sonucunun iki bileşeni eşit olmalı.",
      ],
      "0",
      "φ(1,1) = (2,t+2) = λ(1,1). ⇒ t=0, λ=2.",
    ),
    p(
      7,
      [
        "If C⁻¹AC is diagonal, must the columns of C⁻¹ be eigenvectors of invertible A⁻¹?",
        "C⁻¹AC köşegen ise C⁻¹’in sütunları A⁻¹’in özvektörü olmak zorunda mı?",
      ],
      [
        "Rewrite the diagonalization as a relation for A⁻¹C.",
        "A⁻¹C için eşitliği yeniden yaz.",
      ],
      false,
      "A⁻¹C = CD⁻¹. Örnek (example): C=[1 1; 0 2], D=[1 0; 0 2], A=CDC⁻¹. C⁻¹’in ikinci sütunu (−1/2,1/2) A⁻¹’in özvektörü değildir.",
    ),
    p(
      6,
      [
        "For a real skew-symmetric 2×2 matrix A, is I+A always invertible?",
        "Gerçel 2×2 ters simetrik A için I+A her zaman tersinir mi?",
      ],
      [
        "Write A with one parameter and compute the determinant.",
        "A’yı tek parametreyle yaz ve determinant al.",
      ],
      true,
      "A=[0 a; −a 0] ⇒ det(I+A)=1+a²>0.",
    ),
    p(
      8,
      [
        "For the projector P=[1 3; 3 9]/10, find an orthonormal basis of its kernel.",
        "P=[1 3; 3 9]/10 izdüşüm matrisinin çekirdeğine ortonormal baz bul.",
      ],
      [
        "Solve x+3y=0, then normalize your vector.",
        "x+3y=0 denklemini çöz ve vektörü birimleştir.",
      ],
      null,
      "ker P=span{(−3,1)} ⇒ B={(−3,1)/√10}.",
      [
        [1, 3],
        [3, 9],
      ],
      "solve",
      [0, 0],
    ),
    p(
      0,
      [
        "(1,3) and (1,5) solve a linear system, but (0,0) does not. Give a third solution.",
        "(1,3) ve (1,5) bir sistemin çözümleri. (0,0) çözüm değil. Üçüncü bir çözüm bul.",
      ],
      [
        "Take the midpoint. Its two weights sum to 1.",
        "Orta noktayı al. İki katsayının toplamı 1.",
      ],
      null,
      "(1,4) = ½(1,3)+½(1,5). A((x+y)/2) = (b+b)/2 = b.",
    ),
  ],
  2025: [
    p(
      2,
      [
        "Find a basis of span{(2,3,−2,6),(1,2,−1,4),(9,−4,−9,−8)}. Determine t and coordinates for (t,−1,−1,−2).",
        "Üç vektörün gerdiği uzayın bazını bul. (t,−1,−1,−2) için üyelik sağlayan t ve baz koordinatlarını bul.",
      ],
      [
        "Use the third component to determine t. Solve using the first two generators.",
        "Üçüncü bileşenden t’yi bul. İlk iki vektörle katsayıları çöz.",
      ],
      "1",
      "v₃=22v₁−35v₂. B=(v₁,v₂), dim V=2. x₃=−x₁ ⇒ t=1. 2a+b=1, 3a+2b=−1 ⇒ (a,b)=(3,−5).",
      [
        [2, 1, 9],
        [3, 2, -4],
        [-2, -1, -9],
        [6, 4, -8],
      ],
      "basis",
    ),
    p(
      1,
      [
        "Find the null space of the given 3×4 matrix and extend its basis to ℝ⁴.",
        "Verilen 3×4 matrisin çekirdeğinin bazını, boyutunu ve ℝ⁴’e baz tamamlamasını bul.",
      ],
      [
        "Use x₃ and x₄ as free variables. Extend with e₁ and e₂.",
        "x₃ ve x₄’ü serbest bırak. e₁ ve e₂ ile tamamla.",
      ],
      "2",
      "A=[1 1 −5 −2; 2 1 −8 −4; −1 3 −3 2]. x₁=3x₃+2x₄, x₂=2x₃. B={(3,2,1,0),(2,0,0,1)}; dim V=2. B ∪ {e₁,e₂} bazdır (is a basis).",
      [
        [1, 1, -5, -2],
        [2, 1, -8, -4],
        [-1, 3, -3, 2],
      ],
      "solve",
      [0, 0, 0],
    ),
    p(
      7,
      [
        "For A=[−4 −6; 3 5], find C such that C⁻¹AC=diag(−1,s) and compute A⁵⁰.",
        "A=[−4 −6; 3 5] için C⁻¹AC=diag(−1,s) olacak C’yi ve A⁵⁰’yi bul.",
      ],
      [
        "Put an eigenvector for −1 in the first column of C.",
        "−1 özdeğerinin özvektörünü C’nin ilk sütununa koy.",
      ],
      "2",
      "s=2; C=[−2 −1; 1 1]. A⁵⁰=C diag(1,2⁵⁰) C⁻¹. q=2⁵⁰ ⇒ A⁵⁰=[2−q, 2−2q; q−1, 2q−1].",
      [
        [-4, -6],
        [3, 5],
      ],
      "det",
    ),
    p(
      4,
      [
        "Given A=((3,1),(2,1)), B=((3,2),(1,1)) and F=[−7 −5; 15 11] mapping A-coordinates to B-coordinates, reverse the input/output bases and find φ² in standard coordinates.",
        "A giriş, B çıkış bazıyken F=[−7 −5; 15 11]. Giriş ve çıkış bazlarını değiştir. φ²’nin standart koordinatlardaki formülünü bul.",
      ],
      [
        "Write S=Pᴮ F (Pᴬ)⁻¹ first, then square S.",
        "Önce S=Pᴮ F (Pᴬ)⁻¹ ile standart matrisi bul, sonra karesini al.",
      ],
      "4",
      "S=[−2 0; 0 1]. B → A: (Pᴬ)⁻¹ S Pᴮ=[−10 −4; 12 5]. φ²(x,y)=(4x,y).",
      [
        [-2, 0],
        [0, 1],
      ],
      "product",
    ),
    p(
      6,
      [
        "When is (AAᵀ)² invertible for A=[1 1 t; −5 −1 1; 4 1 −1]? Compute A⁻¹ for t=−2.",
        "(AAᵀ)² hangi t için tersinir? t=−2 için A⁻¹’i bul.",
      ],
      ["Use det((AAᵀ)²)=(det A)⁴.", "det((AAᵀ)²)=(det A)⁴ özelliğini kullan."],
      "-1",
      "det A=−t−1 ⇒ t≠−1. A⁻¹|ₜ₌₋₂=[0 −1 −1; −1 7 9; −1 3 4].",
      [
        [1, 1, -2],
        [-5, -1, 1],
        [4, 1, -1],
      ],
      "inverse",
    ),
    p(
      9,
      [
        "Minimize x₁+x₃+2x₄−x₅ for Ax=(30,24) and x≥0. Check bases {2,3}, {3,4}, {1,2}, then use simplex.",
        "Ax=(30,24), x≥0 altında x₁+x₃+2x₄−x₅’i minimize et. {2,3}, {3,4}, {1,2} bazlarını incele.",
      ],
      [
        "Start at {2,3}. In the simplex step, x₅ can enter and both ratios tie at 6.",
        "{2,3} ile başla. x₅ baza girebilir. Oran testinde iki değer de 6.",
      ],
      "-6",
      "A=[6 12 3 4 5; 5 10 2 3 4]. {2,3}: (0,2,2,0,0) feasible. {3,4}: (0,0,−6,12,0) infeasible. {1,2}: det=0. x₅ enters ⇒ (0,0,0,0,6), min=−6. Reduced costs at {2,5}: x₁=1, x₃=4, x₄=4.",
      [
        [6, 12, 3, 4, 5],
        [5, 10, 2, 3, 4],
      ],
      "solve",
      [30, 24],
    ),
    p(
      7,
      [
        "Give a nondiagonal A with A²−3A+2I=0.",
        "A²−3A+2I=0 sağlayan köşegen olmayan bir matris bul.",
      ],
      [
        "Factor the polynomial and choose a triangular matrix with those diagonal entries.",
        "Polinomu çarpanlara ayır. Kökleri köşegene koyduğun bir üçgensel matris seç.",
      ],
      null,
      "A=[2 1; 0 1]. A²=[4 3; 0 1], so A²−3A+2I=0.",
    ),
    p(
      6,
      [
        "If A⁷−A⁵+4I=0, must A be invertible?",
        "A⁷−A⁵+4I=0 ise A tersinir olmak zorunda mı?",
      ],
      [
        "Factor A out of the first two terms.",
        "İlk iki terimin ortak çarpanı A’yı dışarı al.",
      ],
      true,
      "A(A⁶−A⁴)=−4I ⇒ A⁻¹=−(A⁶−A⁴)/4.",
    ),
    p(
      8,
      [
        "Find the length of the shortest solution to x₁−x₂−x₃=3.",
        "x₁−x₂−x₃=3 denkleminin en kısa çözümünün normunu bul.",
      ],
      [
        "The closest point to 0 lies along the normal (1,−1,−1).",
        "0’a en yakın nokta normal (1,−1,−1) doğrusu üzerindedir.",
      ],
      null,
      "x=(1,−1,−1) ⇒ ‖x‖=√3.",
    ),
    p(
      7,
      [
        "If A is symmetric negative definite, is A⁻³ negative definite?",
        "A simetrik ve negatif tanımlıysa A⁻³ de negatif tanımlı mı?",
      ],
      ["Track the sign of λ⁻³ for λ<0.", "λ<0 için λ⁻³’ün işaretine bak."],
      true,
      "A=Q diag(λᵢ) Qᵀ, λᵢ<0 ⇒ A⁻³=Q diag(λᵢ⁻³) Qᵀ, λᵢ⁻³<0.",
    ),
    p(
      8,
      [
        "Can an orthogonal projector send (1,2,3) to (1,1,1)?",
        "Bir dik izdüşüm (1,2,3) vektörünü (1,1,1)’e gönderebilir mi?",
      ],
      [
        "Check whether the image and residual are perpendicular.",
        "Görüntü ile fark vektörünün dikliğini kontrol et.",
      ],
      false,
      "(1,1,1)·((1,2,3)−(1,1,1))=(1,1,1)·(0,1,2)=3 ≠ 0.",
    ),
  ],
};

export const examLabels = {
  2025: "January 2025 · B",
  2023: "February 2023 · B",
  "2022A": "February 2022 · A",
  "2022B": "February 2022 · B",
  "2019B": "February 2019 · B",
  "2017A": "February 2017 · A",
};
Object.assign(exams, {
  "2017A": [
    p(
      2,
      [
        "When are these columns independent if the last entry of column 3 is t? Give an equation for the span at t=3.",
        "3. sütunun son elemanı t ise sütunlar ne zaman bağımsız? t=3 için gerilen uzayın denklemini bul.",
      ],
      [
        "Subtract column 2 minus column 1 from column 3.",
        "3. sütundan 2. ve 1. sütunun farkını çıkar.",
      ],
      "2",
      "v₃ − (v₂ − v₁) = (0,0,0,t−2). t≠2 ⇒ rank=3. At t=3, span = {x ∈ ℝ⁴ | x₁=x₃}.",
      [
        [1, 2, 1],
        [1, 1, 0],
        [1, 2, 1],
        [1, 3, 3],
      ],
      "rank",
    ),
    p(
      1,
      [
        "Find a basis and dimension for ker A. Extend it to ℝ⁵ and give the coordinates of e₁ in the extended basis.",
        "ker A için baz ve boyut bul. Bazı ℝ⁵’e tamamla ve e₁’in koordinatlarını bul.",
      ],
      [
        "Use x₄ and x₅ as free variables and append e₁,e₂,e₃.",
        "x₄ ve x₅’i serbest bırak. e₁,e₂,e₃’ü ekle.",
      ],
      "2",
      "B = ((2,3,−2,1,0),(−2,2,−1,0,1),e₁,e₂,e₃). dim ker A=2; [e₁]ᴮ=(0,0,1,0,0).",
      [
        [1, 1, 2, -1, 2],
        [1, 1, 3, 1, 3],
        [2, 3, 5, -3, 3],
      ],
      "solve",
      [0, 0, 0],
    ),
  ],
  "2019B": [
    p(
      2,
      [
        "Find a basis of the column space, extend it to ℝ⁴ and give the new coordinates of (1,1,1,1).",
        "Sütun uzayının bazını bul, ℝ⁴’e tamamla ve (1,1,1,1)’in yeni koordinatlarını bul.",
      ],
      [
        "Pivot columns are 1–3. Use e₁ as the fourth vector.",
        "Pivot sütunlar 1–3. Dördüncü vektör olarak e₁’i kullan.",
      ],
      "3",
      "v₄=v₁−v₂. B=(v₁,v₂,v₃,e₁), dim V=3. [(1,1,1,1)]ᴮ=(8,−1,−2,0).",
      [
        [1, 1, 3, 0],
        [0, 1, -1, -1],
        [1, 3, 2, -2],
        [2, 1, 7, 1],
      ],
      "basis",
    ),
    p(
      1,
      [
        "Find a basis and dimension of ker A, then write an equation for span(ker A ∪ {e₂}).",
        "ker A’nın bazını ve boyutunu bul. Ardından span(ker A ∪ {e₂}) için denklem yaz.",
      ],
      [
        "First find the null-space basis; then find a normal perpendicular to the two basis vectors and e₂.",
        "Önce çekirdeğin bazını bul. Sonra iki baz vektörüne ve e₂’ye dik bir normal bul.",
      ],
      "2",
      "ker A = span{(1,−1,1,0),(−4,1,0,1)}; dim=2. W = {x | x₁−x₃+4x₄=0}.",
      [
        [1, 2, 1, 2],
        [2, 5, 3, 3],
      ],
      "solve",
      [0, 0],
    ),
  ],
  "2022A": [
    p(
      2,
      [
        "Find a basis and dimension of the column space, then describe it by an equation.",
        "Sütun uzayının bazını ve boyutunu bul. Uzayı bir denklemle yaz.",
      ],
      [
        "The first two columns are pivot columns. Find a normal to them.",
        "İlk iki sütun pivot sütun. Bu ikisine dik bir normal bul.",
      ],
      "2",
      "B = ((2,1,3),(1,1,−1)). v₃=−v₂, v₄=2v₁+2v₂. dim V=2; −4x₁+5x₂+x₃=0.",
      [
        [2, 1, -1, 6],
        [1, 1, -1, 4],
        [3, -1, 1, 4],
      ],
      "basis",
    ),
    p(
      1,
      [
        "Find a basis of ker A. When does (4,t²,−1,1) belong to it? Give its coordinates.",
        "ker A için baz bul. (4,t²,−1,1) hangi t için çekirdekte? Koordinatlarını bul.",
      ],
      [
        "Substitute the target into either row. Use x₃ and x₄ as the coordinates.",
        "Hedefi bir satıra yerleştir. x₃ ve x₄ baz koordinatlarını verir.",
      ],
      "4",
      "B=((-3,-4,1,0),(1,0,0,1)), dim=2. Substitution ⇒ t²=4 ⇒ t=±2. Coordinates (−1,1).",
      [
        [2, 1, 10, -2],
        [1, 1, 7, -1],
      ],
      "solve",
      [0, 0],
    ),
  ],
  "2022B": [
    p(
      2,
      [
        "Find a basis and dimension of the column space, then describe it by an equation.",
        "Sütun uzayının bazını ve boyutunu bul. Uzayı denklemle yaz.",
      ],
      [
        "Column 3 is the sum of the first two. Column 4 is a multiple of column 2.",
        "3. sütun ilk iki sütunun toplamı. 4. sütun 2. sütunun katı.",
      ],
      "2",
      "B=((1,1,4),(1,2,−1)), dim=2. Normal (−9,5,1) ⇒ −9x₁+5x₂+x₃=0.",
      [
        [1, 1, 2, 3],
        [1, 2, 3, 6],
        [4, -1, 3, -3],
      ],
      "basis",
    ),
    p(
      1,
      [
        "Find a basis of ker A. When does (−5,t²,1,1) belong to it? Give its coordinates.",
        "ker A için baz bul. (−5,t²,1,1) hangi t için çekirdekte? Koordinatlarını bul.",
      ],
      [
        "The last two entries are the free variables; substitute in the second equation.",
        "Son iki eleman serbest değişkenler. Hedefi ikinci denkleme yerleştir.",
      ],
      "1",
      "B=((−4,1,1,0),(−1,0,0,1)), dim=2. t²=1 ⇒ t=±1. Coordinates (1,1).",
      [
        [2, 3, 5, 2],
        [1, 2, 2, 1],
      ],
      "solve",
      [0, 0],
    ),
  ],
});
export const extraCheckpoints = {
  "2017A": ["t (excluded)", "dim ker A"],
  "2019B": ["dim V", "dim ker A"],
  "2022A": ["dim V", "t²"],
  "2022B": ["dim V", "t²"],
};
// Preserve stable exam and question indices for existing progress records.
exams[2023][3].question=["For φ(x,y)=(2x+y,−2x+5y), find eigenvalues, an ordered eigenbasis E and the matrix of φ² from standard coordinates to E-coordinates.","φ(x,y)=(2x+y,−2x+5y) için özdeğerleri, sıralı bir E özbazını ve φ²’nin standart girdiden E-koordinatlı çıktıya matrisini bul."];
exams[2023][3].solution="E=((1,1),(1,2)), λ₁=3, λ₂=4. S²=[[2,7],[−14,23]]. Pᴱ⁻¹ S²=[[18,−9],[−16,16]].";
exams[2023][3].hint=["Solve the characteristic equation, then convert the output of S² into the selected eigenbasis.","Karakteristik denklemi çöz, sonra S²’nin çıktısını seçtiğin özbaza çevir."];
for(const [year,i] of [["2019B",0],["2022A",0],["2022B",0],["2023",0]])exams[year][i].hint=["Reduce first. Use pivot indices to retrieve original columns.","Önce eleme yap. Pivot indeksleriyle orijinal sütunlara dön."];
exams[2025][5].question[0]+=" A=[[6,12,3,4,5],[5,10,2,3,4]].";
exams[2025][5].question[1]+=" A=[[6,12,3,4,5],[5,10,2,3,4]].";
export function examSource(year,i){
 const y=year.slice(0,4), series=year[4]||"B";
 return {file:"final exam "+(y==="2025"?"January":"February")+" "+series+" "+y+".pdf",page:y==="2025"?(i<=3?"1":i===4?"1–2":"2"):y==="2023"?(i<=2?"1":i===3?"1–2":"2"):"1",number:i<6?i+1:i-5};
}
exams[2023][5].question[1]="Ax=(6,8), x≥0 iken −x₂+4x₄’ü minimize et. {3,4}, {2,4}, {1,2} bazlarını dene ve simpleks adımını yap.";
exams[2023][6].question[1]="φ(x,y)=(3x−y,tx+2y) dönüşümünde (1,1) özvektör olacak şekilde t ve λ değerlerini bul.";
exams[2025][3].question[1]="A=((3,1),(2,1)), B=((3,2),(1,1)). A’dan B’ye F=[−7 −5; 15 11]. Bazların yönünü tersine çevir ve φ²’nin standart koordinatlardaki formülünü bul.";
exams[2025][4].question[1]="A=[[1,1,t],[−5,−1,1],[4,1,−1]]. (AAᵀ)² hangi t için tersinir? t=−2 için A⁻¹’i bul.";
exams[2023][9].matrix=[["1/10","3/10"],["3/10","9/10"]];
exams[2025][3].matrix=[[-7,-5],[15,11]];exams[2025][3].operation="transform";exams[2025][3].mapType="frombases";exams[2025][3].domain=[[3,2],[1,1]];exams[2025][3].codomain=[[3,1],[2,1]];
exams[2023][3].operation="transform";exams[2023][3].mapType="compose";exams[2023][3].following=[[2,1],[-2,5]];
exams["2017A"][0].operation="parameter";exams["2017A"][0].param=[[1,2,1],[1,1,0],[1,2,1],[1,3,"t"]];
for(const [y,i] of [["2017A",1],["2025",1]])exams[y][i].hint=["Express pivot variables using free variables. Extend with directions outside the current span.","Pivot değişkenlerini serbest değişkenlerle yaz. Bazı mevcut uzayın dışındaki yönlerle tamamla."];
exams[2025][5].hint=["Determine a feasible basis, then compare reduced costs and admissible step lengths.","Uygun bir baz bul, sonra indirgenmiş maliyetleri ve izin verilen adım uzunluklarını karşılaştır."];
exams[2023][10].hint=["Which combinations of two solutions preserve their right-hand side?","İki çözümün hangi birleşimlerinde sağ taraf aynı kalır?"];
exams[2023][1].solution="B={(−3,−2,1,0),(1,−1,0,1)}, dim ker A=2. b₁ ⇒ −3+2+t=t−1=0. b₂ ⇒ 1+1−2=0.";
exams[2023][7].solution="C=[[1,1],[0,2]], D=diag(1,2), A=CDC⁻¹. z=C⁻¹e₂=(−1/2,1/2); A⁻¹z=(−5/8,1/4) ∉ span{z}.";
exams[2025][1].solution="x₁=3x₃+2x₄, x₂=2x₃. B=((3,2,1,0),(2,0,0,1)); dim ker A=2. rank[B,e₁,e₂]=4.";
exams[2023][5].solutionTR="{3,4}: det=0. {2,4}: (0,2,0,4) uygun. {1,2}: (−4,10,0,0) uygun değil. x₃ girer, x₄ çıkar. x=(0,2,4,0); 2x₁+x₂=2 ⇒ −x₂+4x₄≥−2.";
exams[2025][5].solutionTR="{2,3}: (0,2,2,0,0) uygun. {3,4}: (0,0,−6,12,0) uygun değil. {1,2}: det=0. x₅ girer, x=(0,0,0,0,6), min=−6. {2,5} için indirgenmiş maliyetler: (1,0,4,4,0).";
exams["2022A"][1].solution=exams["2022A"][1].solution.replace("Substitution ⇒","Ax=0 ⇒").replace("Coordinates","[v]ᴮ=");
exams["2022B"][0].solution=exams["2022B"][0].solution.replace("Normal ","n=");
exams["2022B"][1].solution=exams["2022B"][1].solution.replace("Coordinates","[v]ᴮ=");
exams["2017A"][0].solution=exams["2017A"][0].solution.replace("At t=3, span","t=3 ⇒ span");
