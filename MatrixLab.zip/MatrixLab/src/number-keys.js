// Native decimal keyboards differ in their support for signs and fractions.
let activeKeys;
let activeInput;
function clearKeys() {
  activeKeys?.remove();
  activeKeys = activeInput = undefined;
}
// Keep surrounding controls stationary between pointerdown and click.
document.addEventListener("click", event => {
  if (event.target !== activeInput && !activeKeys?.contains(event.target)) clearKeys();
});
document.addEventListener("focusin", ({ target }) => {
  if (!target.matches?.('input[inputmode="decimal"]:not([type="range"])')) return;
  clearKeys();
  activeInput = target;
  const group = target.closest(".matrix") || target.closest("label") || target;
  const keys = document.createElement("div");
  keys.className = "number-keys";
  const tr = document.documentElement.lang === "tr";
  for (const [text, value] of [["−","-"], ["/","/"], ...(target.dataset.sequence ? [[tr?"Boşluk":"Space"," "]] : [])]) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = text;
    button.onpointerdown = event => event.preventDefault();
    button.onclick = () => {
      target.setRangeText(value, target.selectionStart, target.selectionEnd, "end");
      target.dispatchEvent(new Event("input", { bubbles:true }));
    };
    keys.append(button);
  }
  group.after(keys);
  activeKeys = keys;
});
