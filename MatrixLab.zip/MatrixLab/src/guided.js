import {lessons} from './lessons.js';
import {parse,eliminate,system} from './math.js';
export function recall(key,defaultValue){try{return JSON.parse(localStorage.getItem(key))??defaultValue}catch{return defaultValue}}
export function persist(key,value){try{localStorage.setItem(key,JSON.stringify(value))}catch{}}
export function guided(panel,local,load){
  let cursor=0;
  let progress=recall("ml-skills",{}),scope=recall("ml-scope","core"),index=Number(recall("ml-lesson",0)),draft="",feedback="",hint=false,solution=false;
  const pool=()=>lessons.map((c,i)=>({c,i})).filter(({c})=>!!c.extension===(scope==="final"));
  if(!pool().length)scope="core";
  if(!pool().some(x=>x.i===index))index=pool()[0].i;
  function pick(i){cursor=0;index=i;draft="";feedback="";hint=solution=false;persist("ml-lesson",i);render()}
  function render(){
    panel.replaceChildren();const c=lessons[index], exercise=pool();
    function el(tag,text,parent=panel){const x=document.createElement(tag);parent.append(x);x.textContent=text??"";return x}
    function btn(parent,label,action){const b=el("button",label,parent);b.onclick=action;return b}
    function select(label,items,value,change){const s=el("select","",el("label",label));for(const [id,title] of items){el("option",title,s).value=id}s.value=value;s.onchange=()=>change(s.value);return s}
    el("h1",local("Study next","Sıradaki çalışma"));
    select(local("Study scope","Çalışma kapsamı"),[["core",local("Exercises 1–21","Alıştırmalar 1–21")],["final",local("Final preparation","Genel final hazırlığı")]],scope,s=>{scope=s;persist("ml-scope",s);pick(pool().find(({i})=>progress[i]==="review")?.i??pool()[0].i)});
    select(local("Exercise","Alıştırma"),exercise.map(({c,i},n)=>[i,(n+1)+". "+local(...c.title)+(c.number?" · Q"+c.number:"")]),index,x=>pick(+x));
    const source=el("small",c.file?c.file+" · Q"+c.number+" · "+local("PDF p. ","PDF s. ")+c.page:local("MatrixLab self-check","MatrixLab öz değerlendirme"));
    source.className="lesson-source";
    const level=c.file?local("Applied","Uygulama"):local("Foundation","Temel");
    source.textContent+=" · "+level;
    el("h2",local(...c.title));el("p",local(...c.q));
    if(c.matrix&&!["transform","linearity"].includes(c.operation)){
      const numeric=c.matrix.map(r=>r.map(parse));
      const canStep=["basis","pivot","kernel","solve","coords"].includes(c.operation);
      const steps=!canStep?[]:["coords","solve"].includes(c.operation)?system(numeric,(c.target??c.rhs).map(parse)).steps:eliminate(numeric).steps;
      const initial=["coords","solve"].includes(c.operation)?numeric.map((r,i)=>[...r,(c.target??c.rhs)[i]]):c.param??c.matrix;
      const a=cursor?steps[cursor-1].a:initial,holder=el("div");holder.className="lesson-matrix";const table=el("table","",holder);
      const head=el("tr","",table);a[0].forEach((_,j)=>el("th",j===numeric[0].length?"b":"C"+(j+1),head));
      a.forEach(row=>{const tr=el("tr","",table);row.forEach(v=>el("td",String(v),tr))});
      if(steps.length){const controls=el("div");controls.className="bar";btn(controls,local("Previous step","Önceki adım"),()=>{cursor--;render()}).disabled=!cursor;
        btn(controls,local("One row step","Bir satır adımı"),()=>{cursor++;render()}).disabled=cursor===steps.length;
        if(cursor){const o=steps[cursor-1].op;el("span",o.type==="swap"?"R"+(o.i+1)+" ↔ R"+(o.j+1):"R"+(o.i+1)+" ← "+(o.type==="add"?"R"+(o.i+1)+" + ":"")+"("+o.k+") R"+((o.type==="add"?o.j:o.i)+1),controls)}
      }
    }
    const input=el("input","",el("label",local("Answer · separate entries with spaces","Cevap · değerleri boşlukla ayır")));input.value=draft;input.autocomplete="off";
    input.oninput=()=>{draft=input.value;if(!progress[index]){progress[index]="practicing";persist("ml-skills",progress)}};
    const actions=el("div");actions.className="bar";
    function check(){const fields=draft.trim().split(/[\s;]+/),expected=c.answer.split(" ");
      let error="";try{if(!draft.trim()||fields.length!==expected.length)error="size";else if(fields.some((x,i)=>parse(x)!==expected[i]))error="value";if(index===1&&fields.length===2&&parse(fields[0])===expected[0]&&parse(fields[1])!==expected[1])error="ambient";if(index===0&&fields.length===3&&fields.slice(0,2).join(" ")==="1 2"&&parse(fields[2])!=="2")error="rank"}catch{error="format"}
      feedback=error||"ok"; progress[index]=error?"review":"correct";persist("ml-skills",progress);render()}
    input.onkeydown=e=>{if(e.key==="Enter")check()};
    btn(actions,local("Check answer","Cevabı kontrol et"),check).className="primary";
    btn(actions,hint?local("Hide hint","İpucunu gizle"):local("Hint","İpucu"),()=>{hint=!hint;render()});
    btn(actions,solution?local("Hide solution","Çözümü gizle"):local("Show solution","Çözümü gör"),()=>{solution=!solution;render()});
    if(feedback){const msg={ambient:local("Independence is right. Compare the span dimension with three.","Bağımsızlık doğru. Gerilen uzayın boyutunu üçle karşılaştır."),rank:local("The indices are correct. Count the pivot positions for rank.","İndeksler doğru. Rank için pivot konumlarını say."),ok:local("Correct.","Doğru."),size:local("Check the number of entries.","Girdiğin değerlerin sayısını kontrol et."),format:local("Use numbers or fractions.","Sayı veya kesir kullan."),value:local("Check your reasoning. ","Adımını kontrol et. ")+local(...c.hint)};el("p",msg[feedback]).setAttribute("role","status")}
    if(hint)el("p",local(...c.hint));if(solution)el("p",c.solution).className="result";
    if(c.operation&&c.matrix)btn(panel,local("Explore in workspace","Çalışma alanında incele"),()=>load(c));
    const bar=el("div");bar.className="bar";
    btn(bar,local("Mark for review","Tekrara ayır"),()=>{progress[index]="review";persist("ml-skills",progress);render()});
    btn(bar,local("Reset","Sıfırla"),()=>{delete progress[index];persist("ml-skills",progress);pick(index)});
    btn(bar,local("Next exercise","Sonraki alıştırma"),()=>{
      const others=exercise.filter(e=>e.i!==index), next=others.find(e=>progress[e.i]==="review")??others.find(e=>!progress[e.i])??exercise[(exercise.findIndex(e=>e.i===index)+1)%exercise.length];pick(next.i)});
    el("small",({correct:local("Correct","Doğru"),review:local("Needs review","Tekrar gerekli"),practicing:local("Practicing","Çalışılıyor")})[progress[index]]??local("Not started","Başlanmadı"));
  }
  return render;
}
