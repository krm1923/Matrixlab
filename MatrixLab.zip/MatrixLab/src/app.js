import "./number-keys.js";
import studioPage from "virtual:krm-vector-lab";
import {mapFormulas,linearity} from "./linearity.js";
import { practice } from "./practice.js";
import {
  parse,
  add, mul, num,
  neg,
  matrix,
  transpose,
  rowOperation,
  eliminate,
  system,
  inverse,
  binary,
} from "./math.js";
import { words } from "./words.js";
import { geometry } from "./geo.js";
import {pencil,polyText} from "./polynomial.js";
import { expansion, identity } from "./explore.js";
const $ = (id) => document.getElementById(id);
const ops =
  "gauss ref rref manual rank det ind basis span plus minus product inverse solve pivot coords kernel parameter cofactor transform linearity".split(
    " ",
  );
const example = [
  ["2", "1"],
  ["1", "2"],
];
let lang = "en",
  raw = structuredClone(example),
  B = [
    ["1", "0"],
    ["0", "1"],
  ],
  rightSide = ["1", "0"],
  basisTarget = ["1", "0"],
  timeline = [],
  pos = 0,
  operation = "gauss",
  action = "add",
  target = 1,
  source = 0,
  k = "1",
  out = null,
  err = "",
  which = "current",
  mode = "span",
  zoom = 1;
const t = (key) => words[key]?.[lang === "en" ? 0 : 1] || key;
const val = (a) => a.map((r) => r.map(parse));
const safe = (fn) => {
  try {
    return fn();
  } catch {
    return null;
  }
};
const original = () => safe(() => val(raw));
const now = () => (pos ? timeline[pos - 1].a : original());
const currentOp = () => (pos ? timeline[pos - 1].op : null);
const errorText = (e) => t(e || "invalid");
const dim = (a) => a.length + " × " + a[0].length;
const tuple = (v) => "(" + v.join(", ") + ")";
const notation = (o) =>
  o.type === "swap"
    ? "R" + (o.i + 1) + " ↔ R" + (o.j + 1)
    : o.type === "scale"
      ? "R" + (o.i + 1) + " ← (" + o.k + ") R" + (o.i + 1)
      : "R" + (o.i + 1) + " ← R" + (o.i + 1) + " + (" + o.k + ") R" + (o.j + 1);
function node(tag, parent, text, cls) {
  const e = document.createElement(tag);
  if (tag === "input") e.inputMode = "decimal";
  if (text != null) e.textContent = text;
  if (cls) e.className = cls;
  parent.append(e);
  return e;
}
function clear(id) {
  const p = $(id);
  p.replaceChildren();
  return p;
}
function button(p, key, fn, disabled = false) {
  const e = node("button", p, t(key));
  e.onclick = fn;
  e.disabled = disabled;
  return e;
}
function field(p, key) {
  return node("label", p, t(key));
}
function select(p, key, items, value, fn, id, translate = true) {
  const e = node("select", field(p, key));
  e.id = id;
  for (const i of items) {
    const o = node("option", e, translate ? t(i) : i);
    o.value = i;
  }
  e.value = String(value);
  e.onchange = () => fn(e.value);
  return e;
}
const sizes = [1, 2, 3, 4, 5];
function grid(p, a, edit, name, previous) {
  const box = node("div", p, null, "matrix");
  box.style.gridTemplateColumns = "repeat(" + a[0].length + ",minmax(0, 69px))";
  a.forEach((r, i) =>
    r.forEach((value, j) => {
      if (edit) {
        const e = node("input", box);
        e.type = "text";
        if (name === "P") e.inputMode = "text";
        e.autocomplete = "off";
        e.spellcheck = false;
        e.value = value;
        e.placeholder = "0";
        e.ariaLabel = name + " " + (i + 1) + ", " + (j + 1);
        const invalid = () =>
          e.setAttribute(
            "aria-invalid",
            String(safe(() => parse(e.value)) === null),
          );
        if(name!=="P")invalid();
        e.oninput = () => {
          if(name!=="P")invalid();
          edit(i, j, e.value);
        };
      } else {
        const cell = node("div", box, value, "cell");
        if (previous && previous[i][j] !== value) cell.classList.add("changed");
      }
    }),
  );
  return box;
}
function freshHistory() {
  timeline = [];
  pos = 0;
  out = null;
  err = "";
}
function setA(a) {
  const dimensionChanged = a.length !== raw.length;
  raw = a;
  if (dimensionChanged) {
    zoom = 1;
    mode = "vectors";
  }
  freshHistory();
  target = Math.min(1, a.length - 1);
  source = 0;
  rightSide = Array.from({ length: a.length }, (_, i) => rightSide[i] ?? "0");
  basisTarget = Array.from(
    { length: a.length },
    (_, i) => basisTarget[i] ?? "0",
  );
  render();
  if (dimensionChanged) geo.reset();
}
function baseEditor() {
  $("workspace").classList.toggle("parameter-active",operation==="parameter");
  if(operation==="parameter"){
    const p=clear("editor"),bar=clear("dimensions");$("atitle").textContent="P · "+dim(param);
    const resize=(m,n)=>{param=matrix(m,n,(i,j)=>param[i]?.[j]??"0");out=null;err="";render()};
    select(bar,"rows",sizes,param.length,x=>resize(+x,param[0].length),"paramRows",false);
    select(bar,"cols",sizes,param[0].length,x=>resize(param.length,+x),"paramCols",false);
    grid(p,param,(i,j,x)=>{param[i][j]=x;out=null;err="";result()},"P");return;
  }
  const d = clear("dimensions");
  const resize = (rows, cols) =>
    setA(matrix(rows, cols, (i, j) => raw[i]?.[j] ?? ""));
  select(
    d,
    "rows",
    sizes,
    raw.length,
    (x) => resize(+x, raw[0].length),
    "rows",
    false,
  );
  select(
    d,
    "cols",
    sizes,
    raw[0].length,
    (x) => resize(raw.length, +x),
    "cols",
    false,
  );
  button(d, "create", () =>
    setA(matrix(+$("rows").value, +$("cols").value, () => "")),
  );
  button(d, "example", () => setA(structuredClone(example)));
  $("atitle").textContent = "A · " + t("original") + "   " + dim(raw);
  grid(
    clear("editor"),
    raw,
    (i, j, x) => {
      raw[i][j] = x;
      freshHistory();
      derived();
    },
    "A",
  );
}
function picked() {
  const e = clear("opSelect");
  select(
    e,
    "operation",
    ops,
    operation,
    (x) => {
      operation = x;
      out = null;
      err = "";
      baseEditor();
      tools();
      derived();
    },
    "operation",
  );
}
let param = [["1","2"],["0","t-2"]], axis="col", line=0, term=0, focusColumn=0, compareView="original", trial="2";
let linMap="b",linTest="scalar",linU=["1","0","0"],linV=["-1","0","0"],linK="-1";
let transformType="standard", domain=identity(2), codomain=identity(2), following=identity(2);
function tools() {
  const p = clear("options");
  $("run").textContent = t(operation === "manual" ? "apply" : "go");
  if(operation==="parameter"){
    node("p",p,t("pencilHelp"));
    const input=node("input",field(p,"trial"));input.value=trial;input.oninput=()=>{trial=input.value;out=null;result()};
  }
  if(operation==="linearity"){
    const refresh=()=>{out=null;err="";tools();derived()};
    select(p,"mapping",["a","b","c","d"],linMap,x=>{linMap=x;refresh()},"linMap",false);
    node("p",p,mapFormulas[linMap.charCodeAt(0)-97],"formula");
    select(p,"test",["zero","scalar","additive"],linTest,x=>{linTest=x;refresh()},"linTest");
    if(linTest!=="zero"){
      for(const [label,v] of linTest==="additive"?[["u",linU],["v",linV]]:[["u",linU]]){
        node("small",p,label);grid(p,[v],(_,j,x)=>{v[j]=x;out=null;result()},label);
      }
      if(linTest==="scalar"){const e=node("input",field(p,"factor"));e.value=linK;e.oninput=()=>{linK=e.value;out=null;result()}}
    }
  }
  if(operation==="cofactor"){
    const r=node("div",p,null,"bar"), indices=raw.map((_,i)=>i+1);
    line=Math.min(line,indices.length-1);term=Math.min(term,indices.length-1);
    const refresh=()=>{tools();calculate()};
    select(r,"axis",["row","col"],axis,x=>{axis=x;refresh()},"axis");
    select(r,"index",indices,line+1,x=>{line=+x-1;refresh()},"line",false);
    select(r,"element",indices,term+1,x=>{term=+x-1;refresh()},"term",false);
    button(p,"coExample",()=>{axis="col";line=term=0;setA([[2,0,2,0],[1,3,1,2],[0,1,2,1],[0,3,1,4]].map(r=>r.map(String)));calculate()});
  }
  if(operation==="transform"){
    select(p,"operation",["standard","recover","mapbases","frombases","compose","mapSum","change"],transformType,x=>{transformType=x;out=null;tools();derived()},"mapType");
    const editable=(label,values,onedit)=>{node("p",p,label);grid(p,values,(i,j,x)=>{values[i][j]=x;out=null;err="";derived()},label)};
    const fit=(v,n,m)=>matrix(n,m,(i,j)=>v[i]?.[j]??(i===j?"1":"0"));
    domain=fit(domain,raw[0].length,raw[0].length);codomain=fit(codomain,raw.length,raw.length);
    if(["recover","mapbases","frombases"].includes(transformType))editable("Pᵤ",domain);
    if(["mapbases","change","frombases"].includes(transformType))editable("Pᵥ",codomain);
    if(["compose","mapSum"].includes(transformType)){
      const n=transformType==="compose"?raw.length:raw[0].length;
      if(transformType==="compose")select(p,"rows",sizes,following.length,x=>{following=fit(following,+x,n);out=null;tools();derived()},"mapRows",false);
      following=fit(following,transformType==="compose"?following.length:raw.length,n);
      editable("G",following);
    }
  }
  if (operation === "manual") {
    const r = node("div", p, null, "bar block");
    select(
      r,
      "operation",
      ["swap", "scale", "add", "sub"],
      action,
      (x) => {
        action = x;
        err = "";
        tools();
        derived();
      },
      "action",
    );
    const labels = raw.map((_, i) => "R" + (i + 1));
    select(
      r,
      "target",
      labels,
      labels[target],
      (x) => (target = labels.indexOf(x)),
      "target",
      false,
    );
    if (action !== "scale")
      select(
        r,
        "source",
        labels,
        labels[source],
        (x) => (source = labels.indexOf(x)),
        "source",
        false,
      );
    if (action !== "swap") {
      const e = node("input", field(r, "factor"));
      e.value = k;
      e.id = "factor";
      e.oninput = () => (k = e.value);
    }
  }
  if (["plus", "minus", "product"].includes(operation)) {
    const r = node("div", p, null, "bar block");
    node("b", r, "B");
    function resize(m, n) {
      B = matrix(m, n, (i, j) => B[i]?.[j] ?? "");
      out = null;
      err = "";
      tools();
      derived();
    }
    select(
      r,
      "rows",
      sizes,
      B.length,
      (x) => resize(+x, B[0].length),
      "bRows",
      false,
    );
    select(
      r,
      "cols",
      sizes,
      B[0].length,
      (x) => resize(B.length, +x),
      "bCols",
      false,
    );
    grid(
      p,
      B,
      (i, j, x) => {
        B[i][j] = x;
        out = null;
        err = "";
        derived();
      },
      "B",
    );
  }
  if (["solve", "coords"].includes(operation)) {
    const vector = operation === "solve" ? rightSide : basisTarget;
    node("p", p, t(operation === "solve" ? "rhs" : "targetVec"));
    grid(
      p,
      vector.map((x) => [x]),
      (i, j, x) => {
        vector[i] = x;
        err = "";
        out = null;
        derived();
      },
      operation === "solve" ? "b" : "v",
    );
  }
}
function append(steps) {
  if (!steps.length) return;
  timeline = timeline.slice(0, pos).concat(steps);
  pos = timeline.length;
}
function calculate() {
  out = null;
  err = "";
  try {
    const a = operation==="parameter"?null:["basis","span","coords","kernel","transform","cofactor"].includes(operation)?val(raw):now() || val(raw);
    if(operation==="parameter"){
      const v=pencil(param), status=r=>t(r===param[0].length?"independent":"dependent");

      const exceptions=v.cases.map(c=>c.values.join(", ")+" ⇒ rank = "+c.rank+" · "+status(c.rank));
      out={title:operation,lines:[...(v.det!==null?["det = "+polyText(v.det,v.symbol)]:[]),...exceptions.map(x=>t("specialValue")+" "+x),(exceptions.length?t("otherValues"):v.symbol+" ∈ ℝ")+" ⇒ rank = "+v.rank+" · "+status(v.rank),v.symbol+" = "+parse(trial)+" ⇒ rank = "+v.rankAt(parse(trial))],why:"pencilWhy"};
    } else if(operation==="linearity"){
      const check=linearity(linMap,linTest,linU,linV,linK);
      const names={zero:["φ(0)","0"],scalar:["φ(ku)","kφ(u)"],additive:["φ(u+v)","φ(u)+φ(v)"]}[linTest];
      out={title:operation,lines:[names[0]+" = "+tuple(check.left),names[1]+" = "+tuple(check.right)],mat:check.linear?check.matrix:null,why:"linearWhy"+linMap,compareVectors:check};
    } else if(operation==="kernel"){
      const r=system(a,a.map(()=>"0"));
      out={title:operation,mat:r.a.map(row=>row.slice(0,-1)),pairs:[["piv",r.piv.map(j=>"x"+(j+1))],["free",r.free.map(j=>"x"+(j+1))]],text:"ker A = span {"+r.dirs.map(tuple).join(", ")+"} · dim = "+r.dirs.length,lines:["x = "+(r.dirs.map((v,i)=>"t"+(i+1)+tuple(v)).join(" + ")||tuple(r.base))],trace:r.steps,why:"kernelWhy"};
    } else if(operation==="cofactor"){
      if(a.length!==a[0].length)throw Error("square");
      const terms=expansion(a,axis,line), v=terms[term];
      out={title:operation,co:{a,v},lines:["a("+[v.i+1,v.j+1]+") × (−1)^("+[v.i+1,v.j+1].join("+")+") × det M = "+a[v.i][v.j]+" × ("+v.sign+") × ("+v.det+") = "+v.term,"det A = "+terms.map(x=>"("+x.term+")").join(" + ")+" = "+eliminate(a,false).det],why:"coWhy"};
    } else if(operation==="transform"){
      const prod=(x,y)=>binary(x,y,"product");
      let mat=a,formula="φ(x) = A x";
      if(transformType==="recover"){mat=prod(a,inverse(val(domain)));formula="S = Y Pᵤ⁻¹"}
      if(transformType==="change"){inverse(a);mat=prod(inverse(val(codomain)),a);formula="C = Pᵥ⁻¹ A"}
      if(transformType==="mapbases"){inverse(val(domain));mat=prod(prod(inverse(val(codomain)),a),val(domain));formula="[φ]ᵥ←ᵤ = Pᵥ⁻¹ A Pᵤ"}
      if(transformType==="frombases"){inverse(val(codomain));mat=prod(prod(val(codomain),a),inverse(val(domain)));formula="S = Pᵥ F Pᵤ⁻¹"}
      if(transformType==="compose"){mat=prod(val(following),a);formula="G ∘ A = G A"}
      if(transformType==="mapSum"){mat=binary(a,val(following),"plus");formula="(φ + ψ)(x) = (A + G)x"}
      out={title:operation,mat,lines:[formula],why:"mapWhy",coeff:transformType==="standard"};
    } else
    if (operation === "manual") {
      const op = {
        type: action === "sub" ? "add" : action,
        i: target,
        j: source,
      };
      if (action !== "swap") {
        op.k = parse(k);
        if (action === "sub") op.k = neg(op.k);
      }
      append([{ a: rowOperation(a, op), op }]);
      out = { op };
    } else if (["gauss", "ref", "rref"].includes(operation)) {
      const r = eliminate(a, operation === "rref");
      append(r.steps);
      out = {
        title: operation,
        why: r.steps.length
          ? operation === "rref"
            ? "rrefWhy"
            : "refWhy"
          : "done",
        mat: r.a,
      };
      $("history").open = true;
    } else if (["plus", "minus", "product"].includes(operation))
      out = {
        title: operation,
        mat: binary(a, val(B), operation),
        why: operation === "product" ? "whyProduct" : "whySum",
      };
    else if (operation === "inverse") {
      out = {
        title: "inverse",
        mat: inverse(a),
        why: "whyInv",
        trace: eliminate(
          a.map((r, i) => [...r, ...a.map((_, j) => (i === j ? "1" : "0"))]),
          true,
          a.length,
        ).steps,
      };
    } else if (["solve", "coords"].includes(operation)) {
      const r = system(
        a,
        (operation === "solve" ? rightSide : basisTarget).map(parse),
      );
      if (operation === "coords" && r.piv.length !== a[0].length)
        throw Error("notBasis");
      out = {
        title: operation,
        why: operation === "solve" ? "whySolve" : "whyCoords",
        status: r.none
          ? operation === "solve"
            ? "noSol"
            : "outside"
          : r.dirs.length
            ? "infinite"
            : "unique",
        text: r.none
          ? ""
          : (operation === "solve" ? "x" : "c") +
            " = " +
            tuple(r.base) +
            r.dirs.map((d, i) => " + t" + (i + 1) + tuple(d)).join(""),
        lines: operation==="coords"&&!r.none?["v = Pᴮ [v]ᴮ = "+tuple(binary(a,r.base.map(v=>[v]),"product").flat()),...(a.length===a[0].length?["[v]ᴮ = Pᴮ⁻¹ v = "+tuple(r.base)]:[])]:[],
        trace: r.steps,
      };
    } else {
      const r = eliminate(a, false),
        rank = r.piv.length,
        bs = r.piv.map((j) => tuple(transpose(a)[j])),
        free = a[0].map((_, i) => i).filter((i) => !r.piv.includes(i));
      if (operation === "det" && r.det === null) throw Error("square");
      const fields = {
        rank: { text: "rank(A) = " + rank, why: "whyRank" },
        det: { text: "det(A) = " + r.det, why: "whyDet" },
        ind: {
          status: rank === a[0].length ? "independent" : "dependent",
          why: rank === a[0].length ? "whyInd" : "whyDep",
        },
        basis: {
          text: "B = {" + bs.join(", ") + "} · dim = " + rank,
          why: "whyBasis",
        },
        span: {
          text: bs.length ? "span {" + bs.join(", ") + "}" : "{0}",
          why: "whySpan",
        },
        pivot: {
          pairs: [
            ["piv", r.piv.map((i) => i + 1)],
            ["free", free.map((i) => "x" + (i + 1))],
          ],
          why: "whyPivot",
        },
      };
      out = { title: operation, ...fields[operation], trace: r.steps };
    }
  } catch (e) {
    err = e.message;
  }
  derived();
}
function result() {
  const p = clear("result");
  if ((!original() && operation!=="parameter") || err) {
    let key = err;
    if (!key) {
      try {
        val(raw);
      } catch (e) {
        key = e.message;
      }
    }
    node("p", p, errorText(key), "error");
    return;
  }
  if (!out) return;
  const box = node("div", p, null, "result");
  node("b", box, out.op ? notation(out.op) : t(out.title));
  if (["coords","basis","span","kernel","cofactor","transform"].includes(out.title))node("small",box," · A · "+t("original"));
  if (out.status) node("p", box, t(out.status));
  if (out.text) node("div", box, out.text, "formula");
  if(out.compareVectors){
    const {left,right,equal}=out.compareVectors;node("p",box,t(equal?"testHolds":"counterexample"));
    const c=node("canvas",box);c.width=320;c.height=145;c.style.cssText="width:100%;height:145px;background:#24302b;border-radius:7px";
    const ctx=c.getContext("2d"),coords=[left,right].map(v=>v.map(x=>{const [n,d=1]=String(x).split("/");return Number(n)/Number(d)}));
    const k=53/Math.max(1,...coords.flat().map(Math.abs));ctx.strokeStyle="#889a8a";ctx.beginPath();ctx.moveTo(0,72);ctx.lineTo(320,72);ctx.moveTo(160,0);ctx.lineTo(160,145);ctx.stroke();
    coords.forEach(([x,y],i)=>{ctx.strokeStyle=i?"#b7bdff":"#c8ed91";ctx.lineWidth=i?2:5;ctx.setLineDash(i?[5,3]:[]);ctx.beginPath();ctx.moveTo(160,72);ctx.lineTo(160+x*k,72-y*k);ctx.stroke();ctx.beginPath();ctx.arc(160+x*k,72-y*k,i?3:6,0,Math.PI*2);ctx.stroke()});
  }
  if(out.co){
    const {a,v}=out.co;
    const g=grid(box,a);
    [...g.children].forEach((e,k)=>{const i=Math.floor(k/a.length),j=k%a.length;e.classList.toggle("deleted",i===v.i||j===v.j);e.classList.toggle("pivot",i===v.i&&j===v.j)});
    if(v.minor.length){node("small",box,t("minor"));grid(box,v.minor);
      if(v.minor.length>1){const ts=expansion(v.minor,"row",0);node("p",box,"det M = "+ts.map(z=>"("+v.minor[z.i][z.j]+" × "+z.sign+" × "+z.det+")").join(" + ")+" = "+v.det)}
    }
  }
  if(out.lines)out.lines.forEach(x=>node("p",box,x,"formula"));
  if(out.coeff){
    const a=out.mat, n=a[0].length, idx=focusColumn%(n*a.length), i=Math.floor(idx/n),j=idx%n;
    a.forEach((row,r)=>{const f=node("div",box,"φ"+(r+1)+" = ");row.forEach((x,c)=>node("span",f,(c?" + ":"")+"("+x+")x"+(c+1),r===i&&c===j?"pivot":""))});
    const g=grid(box,a);g.children[idx].classList.add("pivot");
    button(box,"nextCoeff",()=>{focusColumn++;result()});
  }
  if (out.mat&&!out.coeff) grid(node("div", box, null, "block"), out.mat);
  if (out.pairs)
    out.pairs.forEach(([key, values]) =>
      node("div", box, t(key) + " · " + (values.join(", ") || t("none"))),
    );
  node("p", box, t(out.op ? out.op.type + "Why" : out.why));
  if(["basis","kernel"].includes(out.title)){
    const details=node("details",box);node("summary",details,t("verifyExtend"));
    const a=original(),selected=out.title==="basis"?eliminate(a,false).piv.map(j=>transpose(a)[j]):system(a,a.map(()=>"0")).dirs;
    const n=out.title==="basis"?a.length:a[0].length,vectors=[...selected],extra=[];
    const rank=vs=>vs.length?eliminate(transpose(vs),false).piv.length:0;
    for(const [i,v] of identity(n).entries())if(rank([...vectors,v])>vectors.length){vectors.push(v);extra.push("e"+(i+1))}
    node("p",details,"rank B = "+rank(selected)+" = dim · "+t("extendWith")+" "+(extra.join(", ")||"∅")+" → ℝ^"+n);
    if(out.title==="basis"){const coords=selected.length?transpose(a).map(v=>tuple(system(transpose(selected),v).base)):[];node("p",details,t("columnCoordinates")+" "+coords.join(" · "))}
    else selected.forEach(v=>node("p",details,"A "+tuple(v)+" = "+tuple(binary(a,v.map(x=>[x]),"product").flat())));
  }
  if (out.trace?.length) {
    const details = node("details", box);
    node("summary", details, t("steps"));
    out.trace.forEach((s) => {
      node("div", details, notation(s.op), "formula");
      grid(details, s.a);
    });
  }
}
function travel(n) {
  pos = n;
  out = null;
  err = "";
  derived();
}
function history() {
  const p = clear("working"),
    a = now();
  let currentPanel=p;
  if(a&&pos){
    const mob=node("div",p,null,"bar only-small"),wrap=node("div",p,null,"compare actual");wrap.dataset.view="current";
    const initial=node("div",wrap);node("small",initial,t("original"));grid(initial,original()).classList.add("original-snapshot");
    currentPanel=node("div",wrap);node("small",currentPanel,t("current"));
    ["original","current"].forEach(key=>button(mob,key,()=>wrap.dataset.view=key));
  }
  if (a)
    grid(
      currentPanel,
      a,
      null,
      null,
      pos ? (pos === 1 ? original() : timeline[pos - 2].a) : null,
    );
  if(a && ["gauss","basis","pivot","ref","rref"].includes(operation)){
    const originalA=original(), reduced=eliminate(originalA), panel=node("details",p);panel.open=operation==="basis"||operation==="pivot";
    node("summary",panel,t("pivotMap"));const bar=node("div",panel,null,"bar only-small");
    const wrap=node("div",panel,null,"compare");
    function show(){wrap.dataset.view=compareView;[...bar.children].forEach((b,i)=>b.setAttribute("aria-pressed",String((i===0?"original":"current")===compareView)))}
    ["original","current"].forEach(key=>button(bar,key==="current"?"rrefShort":key,()=>{compareView=key;show()}));
    [originalA,reduced.a].forEach((m,n)=>{const side=node("div",wrap);node("small",side,n?"RREF(A)":t("original"));const g=grid(side,m);
      [...g.children].forEach((c,k)=>{const j=k%m[0].length,row=Math.floor(k/m[0].length),pivot=reduced.piv.indexOf(j);if(pivot>=0&&(!n||row===pivot))c.classList.add("pivot");});
    });show();node("p",panel,t("pivotExplain"));reduced.piv.forEach((j,i)=>node("div",panel,"("+[i+1,j+1]+") → v"+(j+1)+" = "+tuple(transpose(originalA)[j])));
    node("div",panel,t("free")+" · "+(originalA[0].map((_,j)=>reduced.piv.includes(j)?null:j+1).filter(Boolean).join(", ")||"∅"));
  }
  if (currentOp()) {
    node("div", p, notation(currentOp()), "formula");
    node("p", p, t(currentOp().type + "Why"));
  }
  const bar = clear("historyBar");
  if(a&&["gauss","ref","rref","basis","pivot"].includes(operation)){
    const step=eliminate(a,operation!=="ref").steps[0];button(bar,"oneStep",()=>{append([step]);out=null;derived()},!step);
  }
  button(bar, "undo", () => travel(pos - 1), !pos);
  button(bar, "redo", () => travel(pos + 1), pos === timeline.length);
  button(bar, "reset", () => travel(0), !pos);
  const log = clear("log");
  if (!timeline.length) {
    node("p", log, t("empty"));
    return;
  }
  const base = button(log, "original", () => travel(0));
  base.classList.toggle("on", pos === 0);
  timeline.forEach((s, i) => {
    let b = node(
      "button",
      log,
      i + 1 + ". " + notation(s.op),
      pos === i + 1 ? "on" : "",
    );
    b.onclick = () => travel(i + 1);
  });
}
function properties() {
  const p = clear("properties"),
    a = original(),
    b = now();
  if (!a) return;
  const tbl = node("table", p),
    h = node("tr", tbl);
  ["", "original", "current"].forEach((k) => node("th", h, k ? t(k) : ""));
  const stats = [a, b].map((m) => {
    const r = eliminate(m, false);
    return [
      r.piv.length,
      r.det ?? "—",
      r.piv.map((x) => x + 1).join(", ") || "∅",
      r.piv.length,
      r.piv.map((j) => tuple(transpose(m)[j])).join(" ") || "∅",
    ];
  });
  ["rank", "det", "piv", "dim", "columnBasis"].forEach((key, i) => {
    const r = node("tr", tbl);
    node("th", r, t(key));
    stats.forEach((s) => node("td", r, s[i]));
  });
}
let editVectors = false;
function vectorsView(){
  if(operation==="parameter"){operation="span";baseEditor();picked();tools();derived()}
  which="original"; editVectors=true;mode="span";geometryControls();requestAnimationFrame(()=>geo.draw());
}
const geo = geometry(
  $("plot"),
  () => ({
    a: which === "original" ? original() : now(),
    mode,
    t,
    editable: editVectors && which === "original",
  }),
  (msg, d) => {
    $("geoCaption").textContent = msg;
    $("geoDim").textContent = d;
  },
  (column, vector) =>
    setA(
      raw.map((row, i) =>
        row.map((value, j) => (j === column ? String(vector[i]) : value)),
      ),
    ),
);
function geometryControls() {
  const r = clear("geoOptions");
  select(
    r,
    "view",
    ["original", "current"],
    which,
    (x) => {
      which = x;
      geometryControls();
      geo.draw();
    },
    "geoView",
  );
  const modes = ["vectors", "span"];
  if (raw.length === raw[0].length && [2, 3].includes(raw.length))
    modes.push("shape");
  if (!modes.includes(mode)) mode = "span";
  select(
    r,
    "geometry",
    modes,
    mode,
    (x) => {
      mode = x;
      geometryControls();
      geo.draw();
    },
    "geoMode",
  );
  if ([2, 3].includes(raw.length)) {
    const dragButton = button(r, "editVectors", () => {
      editVectors = !(
        editVectors &&
        which === "original" &&
        mode !== "shape"
      );
      if (editVectors) {
        which = "original";
        if(mode==="shape")mode = "vectors";
      }
      geometryControls();
      geo.draw();
    });
    dragButton.setAttribute(
      "aria-pressed",
      String(editVectors && which === "original" && mode !== "shape"),
    );
  }
  const z = clear("viewControls");
  const e = node("input", field(z, "zoom"));
  e.type = "range";
  e.min = 0.4;
  e.max = 2;
  e.step = 0.05;
  e.value = zoom;
  e.oninput = () => geo.zoom((zoom = +e.value));
  button(z, "home", () => {
    e.value = zoom = 1;
    geo.reset();
  });
}
function derived() {
  history();
  properties();
  result();
  geo.draw();
}
function render() {
  document.documentElement.lang = lang;
  document
    .querySelectorAll("[data-t]")
    .forEach((e) => (e.textContent = t(e.dataset.t)));
  study.render();
  ["en", "tr"].forEach((l) => {
    $(l).classList.toggle("on", lang === l);
    $(l).setAttribute("aria-pressed", String(lang === l));
  });
  baseEditor();
  picked();
  tools();
  geometryControls();
  derived();
}
for (const l of ["en", "tr"])
  $(l).onclick = () => {
    const traceOpen = $("result").querySelector("details")?.open;
    lang = l;
    render();
    if(out&&operation==="parameter")calculate();
    if (traceOpen && $("result").querySelector("details"))
      $("result").querySelector("details").open = true;
  };
const study = practice(
  () => lang,
  (card) => {
    operation = card.operation;
    if(card.target)basisTarget=card.target.map(String);
    if(card.param)param=card.param.map(r=>r.map(String));
    if(card.linMap)linMap=card.linMap;
    if(card.mapType)transformType=card.mapType;
    if(card.following)following=card.following.map(r=>r.map(String));
    if(card.domain)domain=card.domain.map(r=>r.map(String));
    if(card.codomain)codomain=card.codomain.map(r=>r.map(String));
    if (card.rhs) rightSide = card.rhs.map(String);
    if (operation === "product") B = card.matrix.map((row) => row.map(String));
    setA(card.matrix.map((row) => row.map(String)));
    if(operation==="span"){mode="span";which="original";editVectors=true;geometryControls();geo.draw()}
    study.open(false);
    $("workspace").scrollIntoView({ block: "start" });
  }, vectorsView,
);
$("run").onclick = calculate;
render();

const studio=$("vectorStudio"), frame=$("vectorFrame");
$("openStudio").onclick=()=>{
  const a=original();
  const vectors=a&&[2,3].includes(a.length)?transpose(a).map(v=>[num(v[0]),num(v[1]),v.length===3?num(v[2]):0]):null;
  studio.showModal();
  if(!frame.hasAttribute("srcdoc")){
    frame.onload=()=>{if(vectors)frame.contentWindow.postMessage({type:"matrixlab-columns",vectors},"*");frame.onload=null};
    frame.srcdoc=studioPage;
  }else if(vectors)frame.contentWindow.postMessage({type:"matrixlab-columns",vectors},"*");
};
$("closeStudio").onclick=()=>studio.close();
