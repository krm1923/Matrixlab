import { transpose, parse, num, eliminate } from "./math.js";
const colors = ["#c7ec94", "#a7b4ff", "#ffb98c", "#70d7d2", "#ebaada"];
const sum = (a, b) => a.map((x, i) => x + b[i]),
  times = (a, k) => a.map((x) => x * k),
  dot = (a, b) => a.reduce((v, x, i) => v + x * b[i], 0),
  unit = (a) => times(a, 1 / Math.hypot(...a));
export function geometry(canvas, get, caption, commitVector) {
  let endpoints = [],
    drag = null;
  let yaw = 0.72,
    pitch = 0.38,
    zoom = 1,
    start, pointer=null;
  function draw() {
    endpoints = [];
    const { a, mode, t, editable } = get(),
      ctx = canvas.getContext("2d"),
      w = canvas.clientWidth,
      h = canvas.clientHeight,
      d = Math.min(devicePixelRatio, 2);
    canvas.width = Math.round(w * d);
    canvas.height = Math.round(h * d);
    ctx.scale(d, d);
    ctx.lineJoin = "round";
    ctx.clearRect(0, 0, w, h);
    if (!a || ![2, 3].includes(a.length)) {
      caption(a ? t("range") : t("invalid"), "");
      return;
    }
    const dim = a.length,
      vs = transpose(a).map((v) => v.map(num)),
      info = eliminate(drag ? a.map((row,i)=>row.map((v,j)=>j===drag.index?parse(String(drag.value[i])):v)):a, false),
      rank = info.piv.length,
      shape = mode === "shape" && vs.length === dim;
    if (drag) vs[drag.index] = drag.value;
    const basis = info.piv.map((i) => vs[i]),
      max = Math.max(1, ...vs.map((v) => Math.hypot(...v))) * (shape ? 1.7 : 1);
    if (!Number.isFinite(max)) {
      caption(t("oversize"), "");
      return;
    }
    const k = drag?.scale ?? (Math.min(w * 0.4, h * 0.36) / max) * zoom,
      origin = Array(dim).fill(0),
      axes = origin.map((_, j) => origin.map((_, i) => (i === j ? 1 : 0)));
    const project = ([x, y, z = 0]) => {
      const u = dim === 3 ? x * Math.cos(yaw) - y * Math.sin(yaw) : x,
        v =
          dim === 3
            ? z * Math.cos(pitch) -
              (x * Math.sin(yaw) + y * Math.cos(yaw)) * Math.sin(pitch)
            : y;
      return [w / 2 + k * u, h / 2 - k * v];
    };
    const path = (ps, c, width = 1, fill = "", dash = []) => {
      ctx.beginPath();
      ps.map(project).forEach(([x, y], i) =>
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y),
      );
      ctx.strokeStyle = c;
      ctx.lineWidth = width;
      ctx.setLineDash(dash);
      if (fill) {
        ctx.closePath();
        ctx.fillStyle = fill;
        ctx.fill();
      }
      ctx.stroke();
      ctx.setLineDash([]);
    };
    const label = (v, str, c) => {
      const [x, y] = project(v);
      ctx.fillStyle = c;
      ctx.font = "12px monospace";
      ctx.fillText(str, x + 5, y - 5);
    };
    const size = max * 1.2;
    if (mode === "span" && rank === 2) {
      const u = unit(basis[0]),
        b = basis[1],
        v = unit(sum(b, times(u, -dot(u, b))));
      path(
        [
          [-1, -1],
          [1, -1],
          [1, 1],
          [-1, 1],
        ].map(([i, j]) => times(sum(times(u, i), times(v, j)), size)),
        "#a4d39466",
        1,
        "#a4d39422",
      );
    }
    if (mode === "span" && rank === 1) {
      let v = times(unit(basis[0]), size * 2);
      path([times(v, -1), v], "#badd8c", 3);
    }
    for (let i = -4; i <= 4; i++) {
      const p = (i * size) / 4;
      path(
        [
          [-size, p, 0],
          [size, p, 0],
        ],
        "#46534d",
      );
      path(
        [
          [p, -size, 0],
          [p, size, 0],
        ],
        "#46534d",
      );
      if (mode === "span" && rank === 3)
        for (let j = -4; j <= 4; j++)
          path(
            [
              [p, (j * size) / 4, -size],
              [p, (j * size) / 4, size],
            ],
            "#acc99438",
          );
    }
    axes.forEach((v, i) => {
      path([times(v, -size), times(v, size)], "#96a899");
      label(times(v, size), "xyz"[i], "#c4d7c9");
    });
    function edges(vs, c, dash) {
      for (let i = 0; i < 2 ** dim; i++) {
        const p = vs.reduce(
          (a, v, j) => (i & (1 << j) ? sum(a, v) : a),
          origin,
        );
        vs.forEach((v, j) => {
          if (!(i & (1 << j))) path([p, sum(p, v)], c, 1.6, "", dash);
        });
      }
    }
    if (shape) {
      edges(axes, "#e6e9df", [4, 4]);
      edges(vs, "#ffbd8f", []);
    }
    vs.forEach((v, i) => {
      const c = colors[i],
        [x, y] = project(v),
        [ox, oy] = project(origin),
        angle = Math.atan2(y - oy, x - ox);
      if (Math.hypot(x - ox, y - oy) > 2) {
        path([origin, v], c, 2.8);
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle);
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-11, 4);
        ctx.lineTo(-11, -4);
        ctx.fillStyle = c;
        ctx.fill();
        ctx.restore();
      }
      if (editable && mode !== "shape") {
        endpoints.push({ x, y, index: i, vector: v, scale: k });
        ctx.beginPath();
        ctx.arc(x, y, 5, 0, Math.PI * 2);
        ctx.strokeStyle = c;
        ctx.stroke();
      }
      label(v, "v" + (i + 1), c);
    });
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, 3, 0, 2 * Math.PI);
    ctx.fillStyle = "#fff";
    ctx.fill();
    caption(
      [
        shape
          ? t(dim === 2 ? "area" : "volume") +
            " = " +
            info.det +
            " · " +
            t("unit")
          : t("span") + " · " + t(["point", "line", "plane", "space"][rank]),
        t(rank===vs.length?"independent":"dependent")+" · rank "+rank+" · "+t(rank===dim?"spansAll":"properSpan")+" ℝ"+(dim===3?"³":"²"),
        dim === 3 ? t("drag") : "",
      ]
        .filter(Boolean)
        .join(" "),
      dim + "D",
    );
  }
  canvas.onpointerdown = (e) => {
    if(pointer!==null)return;
    pointer=e.pointerId;
    canvas.setPointerCapture(e.pointerId);
    start = [e.clientX, e.clientY];
    const box = canvas.getBoundingClientRect();
    const hit = endpoints
      .map((p) => ({
        ...p,
        distance: Math.hypot(
          p.x + box.left - e.clientX,
          p.y + box.top - e.clientY,
        ),
      }))
      .sort((a, b) => a.distance - b.distance)[0];
    if (hit?.distance < 24)
      drag = { ...hit, value: hit.vector, pointerId: e.pointerId };
  };
  canvas.onpointermove = (e) => {
    if (!start || pointer!==e.pointerId) return;
    if (drag) {
      if (e.pointerId !== drag.pointerId) return;
      const x = (e.clientX - start[0]) / drag.scale;
      const y = (start[1] - e.clientY) / drag.scale;
      const delta =
        drag.vector.length === 2
          ? [x, y]
          : [
              x * Math.cos(yaw) - y * Math.sin(yaw) * Math.sin(pitch),
              -x * Math.sin(yaw) - y * Math.cos(yaw) * Math.sin(pitch),
              y * Math.cos(pitch),
            ];
      drag.value = sum(drag.vector, delta).map(
        (n) => Math.round(n * 100) / 100,
      );
      draw();
      return;
    }
    if (get().a?.length !== 3) return;
    yaw += (e.clientX - start[0]) * 0.01;
    pitch = Math.max(
      -1.5,
      Math.min(1.5, pitch + (e.clientY - start[1]) * 0.008),
    );
    start = [e.clientX, e.clientY];
    draw();
  };
  canvas.onpointerup = (e) => {
    if(pointer!==e.pointerId)return;
    pointer=null;
    const completed = drag;
    drag = null;
    start = null;
    if (completed && completed.value !== completed.vector)
      commitVector(completed.index, completed.value);
    draw();
  };
  canvas.onpointercancel = canvas.onlostpointercapture = e => {
    if(pointer!==e.pointerId)return;pointer=null;
    drag = null;
    start = null;
    draw();
  };
  new ResizeObserver(draw).observe(canvas);
  return {
    draw,
    zoom(x) {
      zoom = x;
      draw();
    },
    reset() {
      yaw = 0.72;
      pitch = 0.38;
      zoom = 1;
      draw();
    },
  };
}
