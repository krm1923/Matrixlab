# MatrixLab

Open **MatrixLab.html** in a modern browser for the self-contained local application. For development, install Node 22 or later and run the following from this folder.

    npm ci
    npm run dev

Open the local URL printed by Vite. The project requires no account, backend, external fonts, or deployment.

## Work with a matrix

Select rows and columns, then choose Create blank. Blank entries represent zero. Fractions and terminating decimals are evaluated as exact rational numbers. The preloaded example is editable. EN / TR changes the interface while retaining values, results and the history cursor.

The editor defines the original matrix. The operation selector acts on the current matrix. Row operations and automatic elimination produce a sequence of snapshots. Undo, Redo and the history list navigate them. Reset returns to the original snapshot. Applying a new operation after Undo starts a new branch of history. Editing the original starts a fresh row history. Calculations on A and B use their displayed dimensions.

For a system, enter the right-hand side corresponding to the current matrix. Solve uses the entire augmented matrix internally. Coordinates accepts independent basis columns, including a basis of a proper subspace, and checks whether the target lies in its span.

Geometry uses matrix columns as vectors. Switch between original and current to compare their images. For square matrices of order 2 or 3, choose Transformation to compare the unit square or cube with its image. 3D geometry supports pointer rotation. Display coordinates use floating point while algebraic results are exact.

## Local checks

    npm test
    npx playwright install chromium
    node tests/browser.js
    npm run build

The browser suite starts and closes its own local Vite server. Set CHROMIUM_PATH to use an installed Chromium executable. The Pages workflow builds dist on pushes to main. Select GitHub Actions under Settings → Pages.

## Guided learning

Study opens one checkpoint at a time. Choose Exercises 1–21 or Final preparation. Enter ordered answers separated by spaces. Review flags and completed checkpoints are saved in this browser. The original 30 final cards retain their IDs. Matrix and Vectors share the same input columns. Basis, span, kernel, coordinates, cofactor and transformation tools use the original matrix.

The parameter editor accepts one real variable with rational polynomial coefficients. Higher-degree exceptional values can appear as exact real-root conditions. Practice cards check the indicated intermediate answer in multi-part exam problems.

Additional checks: run `node tests/learning-browser.js` with Playwright Chromium or set MATRIX_BROWSER=webkit for WebKit. Run `python tests/source_audit.py` with SymPy to independently check the exercise answers. Physical iPhone and iPad hardware require a separate device test.

## KRM Vektör

Open Vectors or the geometry panel and choose KRM Vektör to open the embedded 3D studio. Two-component columns open in the xy-plane. MatrixLab retains its exact matrix while the studio works on a numerical copy. The original English studio includes camera rotation, endpoint editing, two-finger pan and pinch, presets and file controls.
