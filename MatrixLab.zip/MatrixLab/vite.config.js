import {defineConfig} from 'vite';
import {build} from 'esbuild';
import {readFile} from 'node:fs/promises';
export default defineConfig({base:'./',plugins:[{
 name:'embedded-vector-lab',
 resolveId(id){if(id==='virtual:krm-vector-lab')return '\0krm-vector-lab'},
 async load(id){
  if(id!=='\0krm-vector-lab')return;
  const files=['index.html','src/style.css','src/app.js','src/model.js','src/math.js','src/scene.js'];
  files.forEach(file=>this.addWatchFile('geometry/'+file));
  const [page,css,bundle]=await Promise.all([readFile('geometry/index.html','utf8'),readFile('geometry/src/style.css','utf8'),build({entryPoints:['geometry/src/app.js'],bundle:true,minify:true,write:false,format:'iife',target:'es2021'})]);
  const html=page.replace('<link rel="stylesheet" href="./src/style.css">',()=>'<style>'+css+'</style>').replace('<script type="module" src="./src/app.js"></script>',()=>'<script>'+bundle.outputFiles[0].text+'</script>');
  return 'export default '+JSON.stringify(html);
 }
}]});
