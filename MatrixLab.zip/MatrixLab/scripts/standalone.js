import { readFile, writeFile } from "node:fs/promises";
let html = await readFile("dist/index.html", "utf8");
for (const tag of html.matchAll(/<script[^>]+src="([^"]+)"[^>]*><\/script>/g)) {
  const script = await readFile("dist/" + tag[1].replace(/^\//, ""), "utf8");
  html = html.replace(
    tag[0],
    () =>
      '<script type="module">' +
      script.replaceAll("</script", "<\\/script") +
      "</script>",
  );
}
for (const tag of html.matchAll(/<link[^>]+href="([^"]+\.css)"[^>]*>/g)) {
  const css = await readFile("dist/" + tag[1].replace(/^\//, ""), "utf8");
  html = html.replace(tag[0], () => "<style>" + css + "</style>");
}
await writeFile("MatrixLab.html", html);
