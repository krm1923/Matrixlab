import test from 'node:test';
import assert from 'node:assert/strict';
import {pencil,polyText} from '../src/polynomial.js';
import {expansion} from '../src/explore.js';
import {linearity} from '../src/linearity.js';
import {parse,matrix,eliminate,binary,add} from '../src/math.js';
import {exams,examSource} from '../src/exams.js';
import {lessons} from '../src/lessons.js';

test('Rank strata distinguish repeated roots, multiple roots, rectangular and zero matrices',()=>{
  const testCases=[
    [[['t',0],[0,'t']],2,[[0,['0']]]],
    [[['t',0],[0,'t-1']],2,[[1,['0','1']]]],
    [[['s',0,1],[0,'s',0]],2,[[1,['0']]]],
    [[['a^2+1',0],[0,1]],2,[]],
    [[[0,0],[0,0]],0,[]],
    [[['lambda-1/2',1],[0,1]],2,[[1,['1/2']]]],
    [[['t',0,0],[0,'t',0],[0,0,'t-1']],3,[[1,['0']],[2,['1']]]]
  ];
  for(const [m,rank,cases] of testCases){
    const r=pencil(m);assert.equal(r.rank,rank);
    assert.deepEqual(r.cases.map(c=>[c.rank,c.values.sort()]),cases);
    for(const c of r.cases)for(const v of c.values)assert.equal(r.rankAt(v),c.rank);
  }
  assert.throws(()=>pencil([['t','s']]));
  assert.throws(()=>pencil([['1/t']]));
  assert.equal(polyText(pencil([['t',1],[2,'t']]).det,'t'),'t^2 − 2');
  assert.match(pencil([['t',1],[2,'t']]).cases[0].values[0],/√/);
});

test('Polynomial determinants agree with independent exact elimination under substitution',()=>{
  for(let d=1;d<=5;d++){
    const m=matrix(d,d,(i,j)=>i===j?'t^2+2':i>j?'t-3':'-1/2*t+3');
    const r=pencil(m);for(const t of [-2,0,1,4]){
      const a=matrix(d,d,(i,j)=>parse(i===j?t*t+2:i>j?t-3:-t/2+3));
      const reduce=eliminate(a,false), value=r.det.reduceRight((v,x)=>add(binary([[v]],[[String(t)]],'product')[0][0],x),'0');
      assert.equal(value,reduce.det);assert.equal(r.rankAt(String(t)),reduce.piv.length);
    }
  }
});
test('Each cofactor expansion reconstructs 22 and all recursively expanded minors',()=>{
  const A=lessons[6].matrix.map(r=>r.map(parse));
  for(const axis of ['row','col'])for(let i=0;i<4;i++){
    const ts=expansion(A,axis,i);assert.equal(ts.reduce((s,t)=>add(s,t.term),'0'),'22');
    for(const v of ts)assert.equal(expansion(v.minor,'row',0).reduce((s,t)=>add(s,t.term),'0'),v.det);
  }
  assert.deepEqual(expansion(A,'col',0).map(v=>v.term),['20','2','0','0']);
  assert.equal(expansion([['1/3']],'row',0)[0].term,'1/3');
});
test('Q22, passing one sample does not establish linearity',()=>{
  const u=[1,0,0],v=[-1,0,0];
  for(const test of ['zero','scalar','additive'])for(const m of ['a','b','c','d']){
    const r=linearity(m,test,u,v,'-1');assert.equal(r.linear,['b','d'].includes(m));
    if(r.linear)assert.equal(r.equal,true);
    if(m==='c')assert.equal(r.equal,test==='zero');
  }
});
test('All 30 stable exam identities and verified source page ranges retained',()=>{
  assert.equal(Object.values(exams).flat().length,30);
  for(const [y,cs] of Object.entries(exams))cs.forEach((c,i)=>{const s=examSource(y,i);assert.match(s.file,/\.pdf$/);assert.match(s.page,/^[12](–2)?$/);assert.equal(c.question.length,2)});
  assert.deepEqual(new Set(lessons.filter(c=>c.file?.startsWith('Cebir_')).map(c=>parseInt(c.number))),new Set(Array.from({length:21},(_,i)=>i+1)));
  assert.ok(lessons.filter(c=>c.file==='22 to 30 problems.pdf').every(c=>c.extension));
});
