import test from "node:test";
import assert from "node:assert/strict";
import {
  parse,
  add,
  div,
  mul,
  neg,
  eliminate,
  rowOperation,
  system,
  inverse,
  binary,
  matrix,
} from "../src/math.js";
const q = (a) => a.map((r) => r.map(parse)),
  eye = (n) => matrix(n, n, (i, j) => (i === j ? "1" : "0"));
test("Exact fractions, decimal comma, blank and invalid entries", () => {
  for (const [s, v] of [
    ["-1/2", "-1/2"],
    ["1,25", "5/4"],
    [".01", "1/100"],
    ["1.5/3", "1/2"],
    ["", "0"],
    ["-2/-4", "1/2"],
  ])
    assert.equal(parse(s), v);
  for (const s of ["0/0", "1/", "1a", "1/2/3"]) assert.throws(() => parse(s));
  assert.equal(add(div("1", "3"), div("2", "3")), "1");
});
test("All supported shapes, exact RREF invariance under invertible elementary operations", () => {
  for (let m = 1; m <= 5; m++)
    for (let n = 1; n <= 5; n++) {
      const a = matrix(m, n, (i, j) =>
        parse(String((((i + 1) * (j + 2)) % 7) - 3) + "/3"),
      );
      const red = eliminate(a);
      assert.deepEqual(eliminate(red.a).a, red.a);
      for (const op of [
        { type: "scale", i: 0, k: "-2/3" },
        ...(m > 1
          ? [
              { type: "add", j: 0, i: 1, k: "3/7" },
              { type: "swap", i: 0, j: 1 },
            ]
          : []),
      ])
        assert.deepEqual(eliminate(rowOperation(a, op)).a, red.a);
      let replay = a;
      for (const step of red.steps) {
        replay = rowOperation(replay, step.op);
        assert.deepEqual(replay, step.a);
      }
    }
});
test("Determinants cross checked against permutation expansion, inverse gives identity", () => {
  function det(a) {
    if (a.length === 1) return a[0][0];
    return a[0].reduce(
      (s, x, j) =>
        add(
          s,
          mul(
            j % 2 ? neg(x) : x,
            det(a.slice(1).map((r) => r.filter((_, c) => c !== j))),
          ),
        ),
      "0",
    );
  }
  for (let n = 1; n <= 5; n++) {
    const a = matrix(n, n, (i, j) =>
      parse(String(i === j ? 9 : ((i + j) % 4) - 2) + "/3"),
    );
    assert.equal(eliminate(a).det, det(a));
    assert.deepEqual(binary(a, inverse(a), "product"), eye(n));
  }
  assert.throws(
    () =>
      inverse(
        q([
          [1, 2],
          [2, 4],
        ]),
      ),
    /singular/,
  );
  assert.throws(() => inverse(q([[1, 2]])), /square/);
});
test("Unique, infinite, inconsistent and rectangular coordinate systems", () => {
  let a = q([
      [1, 2, 3],
      [2, 4, 6],
    ]),
    r = system(a, ["1", "2"]);
  assert.deepEqual(r.free, [1, 2]);
  assert.deepEqual(r.base, ["1", "0", "0"]);
  r.dirs.forEach((v) =>
    assert.deepEqual(
      binary(
        a,
        v.map((x) => [x]),
        "product",
      ),
      q([[0], [0]]),
    ),
  );
  assert.ok(system(a, ["1", "3"]).none);
  assert.deepEqual(
    system(
      q([
        [1, 1],
        [0, 1],
        [1, 0],
      ]),
      ["3", "2", "1"],
    ).base,
    ["1", "2"],
  );
  assert.deepEqual(system(q([[0]]), ["0"]).dirs, [["1"]]);
});
test("Basic matrix operations and invalid row actions", () => {
  const a = q([
    [1, 2],
    [3, 4],
  ]);
  assert.deepEqual(
    binary(a, a, "plus"),
    q([
      [2, 4],
      [6, 8],
    ]),
  );
  assert.deepEqual(
    binary(a, a, "minus"),
    q([
      [0, 0],
      [0, 0],
    ]),
  );
  assert.deepEqual(
    binary(a, a, "product"),
    q([
      [7, 10],
      [15, 22],
    ]),
  );
  assert.throws(() => binary(a, [["1"]], "product"), /inner/);
  assert.throws(() => binary(a, [["1"]], "plus"), /same/);
  assert.throws(() => rowOperation(a, { type: "scale", i: 0, k: "0" }));
  assert.throws(() => rowOperation(a, { type: "add", i: 0, j: 0, k: "1" }));
});
