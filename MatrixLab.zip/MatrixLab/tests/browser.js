// Runs the actual development server and Chromium in the same local process group.
import assert from "node:assert/strict";
import { createServer } from "vite";
import { chromium } from "playwright";
const server = await createServer({ server: { host: "127.0.0.1", port: 0 } });
await server.listen();
let browser;
try {
  browser = await chromium.launch({
    executablePath: process.env.CHROMIUM_PATH || undefined,
  });
  const page = await browser.newPage({
    viewport: { width: 1194, height: 834 },
    hasTouch: true,
  });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(server.resolvedUrls.local[0]);
  await page.getByRole("button",{name:"Matrix workspace",exact:true}).click();
  const find = (s) => page.locator(s),
    choose = (id, v) => find("#" + id).selectOption(String(v)),
    run = () => find("#run").click(),
    result = () => find("#result").innerText();
  const click = (name) =>
    page.getByRole("button", { name, exact: true }).click();
  async function dims(m, n) {
    await choose("rows", m);
    await choose("cols", n);
    await click("Create blank");
    assert.equal(await find("#editor input").count(), m * n);
  }
  const setValues = async (selector, values) => {
    for (const [i, x] of values.entries())
      await find(selector).nth(i).fill(String(x));
  };
  await find("#guide summary").click();
  assert.match(await find("#guide").innerText(), /Choose a size/);
  await find("#guide summary").click();
  for (const key of [
    "gauss",
    "ref",
    "rref",
    "rank",
    "det",
    "ind",
    "basis",
    "span",
    "plus",
    "minus",
    "product",
    "inverse",
    "solve",
    "pivot",
    "coords",
  ]) {
    await click("Load example");
    await choose("operation", key);
    await run();
    assert.ok((await result()).length > 12, key);
    assert.equal(await find("#result .error").count(), 0, key);
    if (["ref", "gauss", "rref"].includes(key))
      assert.ok((await find("#log button").count()) > 1);
    if (key === "det") assert.match(await result(), /det\(A\) = 3/);
    if (key === "inverse")
      assert.deepEqual(
        await find("#result>.result>.block .cell").allTextContents(),
        ["2/3", "-1/3", "-1/3", "2/3"],
      );
    if (key === "coords" || key === "solve")
      assert.match(await result(), /\(2\/3, -1\/3\)/);
    await click("TR");
    assert.equal(await find("html").getAttribute("lang"), "tr");
    assert.ok((await result()).length > 8);
    await click("EN");
  }
  await click("Load example");
  await choose("operation", "manual");
  for (const act of ["swap", "scale", "add", "sub"]) {
    await choose("action", act);
    await choose("target", "R2");
    if (act !== "scale") await choose("source", "R1");
    if (act !== "swap") await find("#factor").fill("1/2");
    await run();
    assert.ok((await find("#working .changed").count()) > 0);
    const after = await find("#working .cell").allTextContents();
    await click("Undo");
    await click("Redo");
    assert.deepEqual(await find("#working .cell").allTextContents(), after);
  }
  await click("Reset to original");
  assert.deepEqual(await find("#working .cell").allTextContents(), [
    "2",
    "1",
    "1",
    "2",
  ]);
  if (!(await find("#history").evaluate((e) => e.open)))
    await find("#history summary").click();
  await find("#log button").nth(2).click();
  assert.equal(await find("#log button.on").count(), 1);
  await choose("action", "scale");
  await find("#factor").fill("0");
  await run();
  assert.match(await result(), /nonzero/);
  await click("TR");
  assert.match(await result(), /sıfırdan farklı/);
  await click("EN");
  await dims(5, 5);
  await find("#editor input").first().fill("-0.25");
  await find("#editor input").last().fill("1/3");
  await choose("operation", "rank");
  await run();
  assert.match(await result(), /= 2/);
  await find("#editor input").first().fill("1/0");
  assert.equal(await find("[aria-invalid=true]").count(), 1);
  await run();
  assert.ok(await find("#result .error").isVisible());
  await click("TR");
  assert.equal(await find("#editor input").last().inputValue(), "1/3");
  await click("EN");
  await choose("rows", 1);
  await choose("cols", 5);
  await click("TR");
  assert.equal(await find("#rows").inputValue(), "1");
  await click("EN");
  await click("Create blank");
  assert.match(await find("#geoCaption").innerText(), /two or three/);
  await dims(2, 2);
  await setValues("#editor input", [1, 0, 0, -2]);
  await choose("geoMode", "shape");
  assert.match(await find("#geoCaption").innerText(), /area = -2/);
  await choose("geoView", "original");
  await choose("geoView", "current");
  await choose("operation", "product");
  await choose("bRows", 3);
  await run();
  assert.match(await result(), /must equal/);
  await choose("bRows", 2);
  await choose("bCols", 1);
  await setValues("#options input", ["1/3", 2]);
  await run();
  assert.deepEqual(await find("#result .cell").allTextContents(), [
    "1/3",
    "-4",
  ]);
  await dims(3, 3);
  await setValues("#editor input", [1, 0, 0, 0, 1, 0, 0, 0, -1]);
  await choose("geoMode", "shape");
  assert.match(await find("#geoCaption").innerText(), /volume = -1/);
  await choose("geoMode", "vectors");
  await choose("geoMode", "span");
  assert.match(await find("#geoCaption").innerText(), /Full space/);
  const canvas = find("#plot");
  await canvas.scrollIntoViewIfNeeded();
  const image = () => canvas.evaluate((c) => c.toDataURL());
  const before = await image(),
    box = await canvas.boundingBox();
  await page.mouse.move(box.x + 80, box.y + 70);
  await page.mouse.down();
  await page.mouse.move(box.x + 150, box.y + 90);
  await page.mouse.up();
  assert.notEqual(await image(), before);
  await find("#viewControls input").fill("1.5");
  await click("Reset view");
  assert.equal(await image(), before);
  await find("#editor input").nth(8).fill("0");
  assert.match(await find("#geoCaption").innerText(), /Plane/);
  await find("#editor input").nth(4).fill("0");
  assert.match(await find("#geoCaption").innerText(), /Line/);
  await find("#editor input").nth(0).fill("0");
  assert.match(await find("#geoCaption").innerText(), /Origin/);
  for (const width of [390, 834, 1194]) {
    await page.setViewportSize({ width, height: 850 });
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth > innerWidth,
      ),
      false,
    );
  }
  assert.deepEqual(errors, []);
  console.log(
    "PASS — operations, language, input, row history, geometry, layout and runtime checks",
  );
} finally {
  await browser?.close();
  await server.close();
}
