import assert from "node:assert/strict";
import { createServer } from "vite";
import { chromium, webkit, devices } from "playwright";
const server = await createServer({ server: { host: "127.0.0.1", port: 0 } });
await server.listen();
let browser;
try {
  const engine = process.env.MATRIX_BROWSER === "webkit" ? webkit : chromium;
  browser = await engine.launch({
    executablePath: process.env.CHROMIUM_PATH || undefined,
  });
  const page = await browser.newPage(devices["iPhone 15"]);
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto(server.resolvedUrls.local[0]);
  await page.getByRole("button",{name:"Matrix workspace",exact:true}).click();
  const click = (name) => page.getByRole("button", { name, exact: true }).tap();
  await page.locator("#rows").selectOption("3");
  await page.locator("#cols").selectOption("3");
  assert.equal(await page.locator("#editor input").count(), 9);
  assert.equal((await page.locator("#geoDim").textContent()).trim(), "3D");
  assert.equal(await page.locator("#geoMode").inputValue(), "vectors");
  assert.equal(await page.locator("#editor input").first().inputValue(), "2");
  await click("Load example");
  await click("Drag arrows");
  const canvas = page.locator("#plot");
  await canvas.scrollIntoViewIfNeeded();
  const box = await canvas.boundingBox();
  const scale = Math.min(box.width * 0.4, box.height * 0.36) / Math.sqrt(5);
  const x = box.x + box.width / 2 + 2 * scale;
  const y = box.y + box.height / 2 - scale;
  await page.mouse.move(x, y);
  await page.mouse.down();
  await page.mouse.move(x - 30, y - 22);
  await page.mouse.up();
  assert.notEqual(
    await page.locator("#editor input").first().inputValue(),
    "2",
  );
  await page.setViewportSize({ width: 834, height: 1100 });
  const op = await page.locator(".operation-panel").boundingBox(),
    editor = await page.locator(".editor-panel").boundingBox();
  assert.equal(op.y, editor.y);
  assert.ok(op.x < editor.x);
  await page.setViewportSize({ width: 393, height: 852 });
  assert.ok(
    (await page.locator(".operation-panel").boundingBox()).y <
      (await page.locator(".editor-panel").boundingBox()).y,
  );
  await click("Exam practice");
  assert.equal(await page.locator("#practice select").count(),1);
  for(let i=0;i<30;i++){
    await click("Hint");
    await click("Show solution");
    assert.ok((await page.locator(".exam-card .result").innerText()).length>8);
    if(i<29) await click("Next");
  }
  for(let i=29;i>0;i--) await click("Previous");
  assert.equal(await page.locator("#practice input").getAttribute("inputmode"),"decimal");
  await page.locator("#practice input").fill("2");
  await click("Check");
  assert.match(await page.locator(".exam-card").innerText(), /Try again/);
  await page.locator("#practice input").fill("2/2");
  await click("Check");
  assert.match(await page.locator(".exam-card").innerText(), /Correct/);
  await click("TR");
  assert.equal(await page.locator("#practice input").inputValue(), "2/2");
  await click("MatrixLab’de aç");
  assert.equal(await page.locator("#editor input").count(), 12);
  assert.equal(await page.locator("#operation").inputValue(), "basis");
  assert.equal(
    await page.evaluate(
      () => document.documentElement.scrollWidth > innerWidth,
    ),
    false,
  );
  assert.deepEqual(errors, []);
  console.log(
    "PASS — 30 cards, pooled navigation, hints, solutions, grading, bilingual state, matrix transfer, 2D→3D",
  );
} finally {
  await browser?.close();
  await server.close();
}
