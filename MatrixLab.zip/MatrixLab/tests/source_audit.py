"""Independent answer audit using SymPy. Run from the project root."""
import json
import subprocess
import sympy as s
from itertools import combinations

data = json.loads(subprocess.check_output(["node", "--input-type=module", "-e",
    "import {lessons} from './src/lessons.js';import {exams} from './src/exams.js';console.log(JSON.stringify({lessons,exams}))"]))
M = s.Matrix
t = s.symbols('t', real=True)
def mat(rows):
    return M([[s.Rational(x) for x in r] for r in rows])
def nums(v):
    return ' '.join(str(x) for x in v)
def tune(rows):
    return M([[s.sympify(str(x).replace('2t','2*t'),locals={'a':t,'t':t}) for x in row] for row in rows])
def optimum(A,b,c):
    feasible=[]
    for ix in combinations(range(A.cols),A.rows):
        B=A[:,ix]
        if B.det():
            x=B.inv()*M(b)
            if all(e>=0 for e in x): feasible.append(sum(c[j]*v for j,v in zip(ix,x)))
    return min(feasible)
for i,c in enumerate(data["lessons"]):
    A=mat(c["matrix"]) if c.get("matrix") else None
    P=mat(c["domain"]) if "domain" in c else None
    V=mat(c["codomain"]) if "codomain" in c else None
    G=mat(c["following"]) if "following" in c else None
    b=M(c.get("target",c.get("rhs",[])))
    if i in (0,2,14):
        piv=A.rref()[1];answer=[*(x+1 for x in piv),len(piv)]
    elif i==1:answer=[int(A.rank()==A.cols),int(A.rank()==A.rows)]
    elif i in (3,13,17):
        pencil=tune(c['param'])
        minors=[pencil[list(rows),:].det() for rows in combinations(range(pencil.rows),pencil.cols)]
        answer=s.solve(s.gcd_list(minors),t)
    elif i in (4,20):answer=A.inv()*b
    elif i==5:answer=[1,*A]
    elif i==6:answer=[(-1)**(2+1)];assert A.det()==22
    elif i==7:answer=[int(all(x.is_integer for x in M([1,2])+M([3,4]))),int(s.Rational(1,2).is_integer)]
    elif i==8:answer=list(set(s.solve(t*t-1,t)) & set(s.solve(1-t,t)))
    elif i==9:answer=[int(A.rank()==A.row_join(b).rank())]
    elif i==10:answer=s.solve((A.T.nullspace()[0].T*M([1,1,t]))[0],t)
    elif i==11:answer=[0]*4
    elif i==12:answer=[int(A.rank()==A.cols)]
    elif i==15:answer=[len(A.nullspace())]
    elif i==16:answer=[len(A.T.nullspace())]
    elif i==18:answer=[A.cols-len(A.nullspace())]
    elif i==19:answer=[int(A.rank()>=3)]
    elif i==21:answer=(M([1,2,3])-3*M([1,0,0])-M([0,1,0]))/2
    elif i==22:answer=(M([7,3,5])-3*M([1,0,1])-M([2,1,0]))/2
    elif i==23:answer=list(A)
    elif i==24:answer=list(set(s.solve(t*t-4,t))&set(s.solve(5*t-10,t)))
    elif i==25:answer=(A*P.inv())[:,1]
    elif i==26:answer=(A+G)[:,0]
    elif i==27:answer=(V.inv()*A*P)[:,0]
    elif i==28:answer=V.inv()*A*M([1,3])
    elif i==29:answer=(G*A)[:,0]
    elif i==30:answer=G*A*M([1,-1,3,-2])
    elif i==31:answer=(V.inv()*A)[:,0]
    elif i==32:answer=[s.solve(tune(c['param']).det(),t)[1]**2]
    elif i==33:answer=[4*abs(-1),-4*abs(1)]
    elif i==34:
        vecs=[[-1,1,1,-1],[2,3,1,4],[4,-3,2,1],[4,0,-3,s.Rational(1,2)]]
        answer=[j+1 for j,v in enumerate(vecs) if A*M(v)==b]
    elif i in range(35,39):
        assert A.rank()==A.row_join(b).rank();answer=[A.cols-A.rank()]
    elif i==39:answer=[s.solve(list(A*M([1,t,3,2*t])-b),t)[t]]
    elif i==40:answer=s.solve((A.T.nullspace()[0].T*M([2,7,t]))[0],t)
    elif i==41:answer=A.inv()*b
    else:raise AssertionError(i)
    assert nums(answer)==c['answer'],(i,answer,c['answer'])

for year,cards in data['exams'].items():
    for i,c in enumerate(cards):
        A=mat(c['matrix']) if c.get('matrix') else None
        if i==0 and year in ('2023','2025'):
            target=M([2,-1,t]) if year=='2023' else M([t,-1,-1,-2])
            answer=s.solve(list(M.hstack(*A.T.nullspace()).T*target),t)[t]
        elif i==0 and year=='2017A':
            P=tune(c['param']);answer=s.solve(s.gcd_list([P[list(rr),:].det() for rr in combinations(range(4),3)]),t)[0]
        elif i==0:answer=A.rank()
        elif i==1 and year=='2023':answer=s.solve([(M([[1,-1,t,-2]])*v)[0] for v in A.nullspace()],t)[t]
        elif i==1 and year.startswith('2022'):
            x=M([4,t*t,-1,1]) if year=='2022A' else M([-5,t*t,1,1])
            answer=s.solve(list(A*x),t)[0][0]**2
        elif i==1:answer=len(A.nullspace())
        elif (year,i)==('2023',2):
            B=M([[0,0,3,7],[0,0,2,5],[2,3,0,0],[3,4,0,0]])
            answer=(B.T*A*B*A).det()
        elif (year,i)==('2023',3):
            answer=max(A.eigenvals());P=M([[1,1],[1,2]])
            assert P.inv()*A**2==M([[18,-9],[-16,16]])
        elif (year,i)==('2023',4):
            n=M([1,-1,-1]);v=M([8,1,1]);answer=(v-n*(n.dot(v)/n.dot(n)))[0]
        elif i==5:
            b,cost=([6,8],[0,-1,0,4]) if year=='2023' else ([30,24],[1,0,1,2,-1])
            answer=optimum(A,b,cost)
        elif (year,i)==('2023',6):answer=s.solve(t+2-2,t)[0]
        elif (year,i)==('2023',7):
            C=M([[1,1],[0,2]]);A=C*s.diag(1,2)*C.inv();v=C.inv()[:,1]
            answer=M.hstack(v,A.inv()*v).rank()==1
        elif (year,i)==('2023',8):answer=bool((1+t*t).is_positive)
        elif (year,i)==('2023',9):assert A*M([-3,1])==s.zeros(2,1);continue
        elif (year,i)==('2023',10):assert (M([1,5])+M([1,3]))/2==M([1,4]);continue
        elif (year,i)==('2025',2):
            answer=max(A.eigenvals());q=2**50
            assert A**50==M([[2-q,2-2*q],[q-1,2*q-1]])
        elif (year,i)==('2025',3):
            S=mat(c['codomain'])*A*mat(c['domain']).inv();answer=(S**2)[0,0]
        elif (year,i)==('2025',4):
            A[0,2]=t;answer=s.solve(A.det(),t)[0]
            assert A.subs(t,-2).inv()==M([[0,-1,-1],[-1,7,9],[-1,3,4]])
        elif (year,i)==('2025',6):
            A=M([[2,1],[0,1]]);assert A**2-3*A+2*s.eye(2)==s.zeros(2);continue
        elif (year,i)==('2025',7):answer=(t**7-t**5+4).subs(t,0)!=0
        elif (year,i)==('2025',8):assert s.Rational(3)**2/M([1,-1,-1]).dot(M([1,-1,-1]))==3;continue
        elif (year,i)==('2025',9):answer=bool((s.symbols('z',negative=True)**-3).is_negative)
        elif (year,i)==('2025',10):answer=M([1,1,1]).dot(M([0,1,2]))==0
        else:raise AssertionError((year,i))
        assert str(answer)==str(c['answer']),(year,i,answer,c['answer'])
print('Independent course and final checkpoint audit passed.')
