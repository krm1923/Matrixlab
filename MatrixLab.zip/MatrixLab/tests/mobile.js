import assert from 'node:assert/strict';
import { createServer } from 'vite';
import { chromium, webkit, devices } from 'playwright';

const server = await createServer({server:{host:'127.0.0.1',port:0}});
await server.listen();
let browser;
try {
  const engine = process.env.MATRIX_BROWSER === 'webkit' ? webkit : chromium;
  browser = await engine.launch({executablePath:process.env.CHROMIUM_PATH || undefined});
  const page = await browser.newPage(devices['iPhone 15']);
  const failures = [];
  page.on('pageerror', error => failures.push(error.message));
  await page.goto(process.env.MATRIX_URL || server.resolvedUrls.local[0]);
  await page.getByRole("button",{name:"Matrix workspace",exact:true}).click();
  const el = selector => page.locator(selector);
  const button = name => page.getByRole('button',{name,exact:true});
  const run = () => el('#run').tap();
  const entries = ['0','-2','1/3','-0.25','1,5'];
  async function checkCells(selector,count) {
    const cells = el(selector);
    assert.equal(await cells.count(),count);
    for(let i=0;i<count;i++) await cells.nth(i).fill(entries[i%entries.length]);
    assert.deepEqual(await cells.evaluateAll(inputs => inputs.map(input=>input.value)),Array.from({length:count},(_,i)=>entries[i%entries.length]));
    assert.equal(await el(selector+'[aria-invalid=true]').count(),0);
  }
  for(let rows=1;rows<=5;rows++) for(let cols=1;cols<=5;cols++) {
    await el('#rows').selectOption(String(rows));await el('#cols').selectOption(String(cols));
    await button('Create blank').tap();
    assert.equal(await el('#editor input').count(),rows*cols);
  }
  await checkCells('#editor input',25);
  await el('#operation').selectOption('plus');
  await el('#bRows').selectOption('5');await el('#bCols').selectOption('5');
  await checkCells('#options input',25);await run();
  assert.equal(await el('#result .cell').count(),25);
  await el('#tr').tap();
  assert.equal(await el('html').getAttribute('lang'),'tr');
  assert.equal(await el('#options input').nth(22).inputValue(),'1/3');
  await el('#operation').selectOption('solve');
  await checkCells('#options input',5);
  await el('#operation').selectOption('coords');
  assert.equal(await el('#options input').first().inputValue(),'1');
  await checkCells('#options input',5);
  await el('#options input').first().fill('3/7');
  await el('#operation').selectOption('solve');
  assert.equal(await el('#options input').first().inputValue(),'0');
  await el('#operation').selectOption('coords');
  assert.equal(await el('#options input').first().inputValue(),'3/7');
  await el('#editor input').last().fill('1/0');
  assert.equal(await el('#editor input').last().getAttribute('aria-invalid'),'true');
  await run();
  assert.match(await el('#result').innerText(),/Payda sıfır olamaz/);
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  assert.deepEqual(failures,[]);
  console.log('Mobile touch suite passed: 25 dimensions, 60 matrix/vector fields, EN/TR and validation.');
} finally {await browser?.close();await server.close()}
