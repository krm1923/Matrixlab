import assert from 'node:assert/strict';
import {createServer} from 'vite';
import {chromium,webkit,devices} from 'playwright';
import {lessons} from '../src/lessons.js';
import {exams} from '../src/exams.js';
const server=await createServer({server:{host:'127.0.0.1',port:0}});await server.listen();
let browser;
try{
  const wk=process.env.MATRIX_BROWSER==='webkit';
  browser=await (wk?webkit:chromium).launch({executablePath:process.env.CHROMIUM_PATH||undefined});
  const page=await browser.newPage(devices['iPhone 15']);const errors=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
  await page.goto(server.resolvedUrls.local[0]);const $=s=>page.locator(s);
  const tap=n=>page.getByRole('button',{name:n,exact:true}).tap();
  const select=(s,v)=>$(s).selectOption(String(v));const text=s=>$(s).innerText();
  const fills=async(s,values)=>{for(const [i,v] of values.flat().entries())await $(s).nth(i).fill(String(v))};
  const noOverflow=async()=>assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  assert.equal(await $('#guided').isVisible(),true);
  for(const [i,c] of lessons.entries()){
    await select('#guided select:first-of-type >> nth=0',c.extension?'final':'core');
    await $('#guided select').nth(1).selectOption(String(i));
    assert.equal(await $('#guided .result').count(),0);
    assert.ok(!(await text('#guided')).includes(c.solution),'solution hidden: '+i);
    await $('#guided input').fill(c.answer);await tap('Check answer');
    assert.equal(await text('#guided [role=status]'),'Correct.','grade '+i);
    await tap('Hint');await tap('Hide hint');await tap('Show solution');
    assert.equal(await text('#guided .result'),c.solution);
    await tap('Hide solution');await noOverflow();
    if(c.operation&&c.matrix){
      await tap('Explore in workspace');assert.equal(await $('#operation').inputValue(),c.operation);
      await $('#run').tap();assert.equal(await $('#result .error').count(),0,'workspace: '+i+' '+await text('#result'));
      assert.ok((await text('#result')).length>6);await tap('Study');
    }
  }
  await $('#guided select').first().selectOption('core');await $('#guided select').nth(1).selectOption('0');
  await tap('Reset');await $('#guided input').fill('1 2 3');await tap('Check answer');
  assert.match(await text('#guided'),/indices are correct/);await tap('TR');
  assert.match(await text('#guided'),/İndeksler doğru/);assert.equal(await $('#guided input').inputValue(),'1 2 3');
  await tap('EN');await tap('Mark for review');await page.reload();assert.match(await text('#guided'),/Needs review/);
  await $('#guided select').nth(1).selectOption('14');await tap('One row step');await tap('Previous step');
  await tap('Next exercise');assert.equal(await $('#guided select').nth(1).inputValue(),'0');
  await tap('Explore in workspace');await select('#operation','manual');
  await select('#action','swap');await $('#run').tap();
  await select('#operation','basis');await $('#run').tap();assert.match(await text('#result'),/\(1, 0, 0\), \(2, 1, 0\)/);
  await $('#result details').first().locator('summary').tap();assert.match(await text('#result'),/e3/);
  assert.equal(await $('#working .compare:not(.actual) .pivot').count(),8);
  await $('#working .only-small').last().getByRole('button',{name:'RREF',exact:true}).tap();
  assert.equal(await $('#working .compare:not(.actual)>div').nth(1).isVisible(),true);
  await tap('Reset to original');await tap('One elimination step');await tap('Undo');await tap('Redo');
  await select('#operation','parameter');await select('#paramRows','2');await select('#paramCols','2');
  await fills('#editor input',['t','0','0','t-1']);await $('#run').tap();
  assert.match(await text('#result'),/rank = 1/);await tap('TR');assert.match(await text('#result'),/Özel değerler/);
  await tap('EN');await $('#editor input').first().fill('t+s');await $('#run').tap();assert.ok(await $('#result .error').isVisible());
  await tap('Matrix workspace');if(!await $('#operation').isVisible())console.log('Navigation after touch',await $('#studyNav').innerHTML(),await $('#workspace').getAttribute('class'));await select('#operation','linearity');
  for(const m of ['a','b','c','d'])for(const test of ['zero','scalar','additive']){
    await select('#linMap',m);await select('#linTest',test);await $('#run').tap();assert.equal(await $('#result canvas').count(),0);
  }
  await select('#operation','cofactor');await tap('Load 4 × 4 example');
  for(const axis of ['row','col']){await select('#axis',axis);for(let i=1;i<=4;i++){await select('#line',i);await select('#term',i);assert.match(await text('#result'),/= 22/)}}
  await select('#operation','transform');await select('#mapType','standard');await $('#run').tap();await tap('Next coefficient');assert.equal(await $('#result .pivot').count(),2);
  for(const size of [[320,640],[393,852],[834,1194],[1194,834]]){await page.setViewportSize({width:size[0],height:size[1]});await noOverflow()}
  await tap('Exam practice');
  for(const y of ['2025','2023','2022A','2022B','2019B','2017A']){
    const cs=exams[y];
    for(const [i,c] of cs.entries()){
      if(typeof c.answer==='boolean')await tap(c.answer?'Yes':'No');
      else{const answer=c.answer??({'2023:9':'-6 2','2023:10':'1 2','2025:6':'2 1 0 1','2025:8':'3'})[y+':'+i];await $('#practice input').fill(answer);await tap('Check')}
      assert.match(await text('.exam-card'),/Correct\./,y+':'+i);
      assert.equal(await $('.exam-card .result').count(),0);
      if(y!=='2017A'||i<cs.length-1)await tap('Next');
    }
  }
  for(let i=29;i>0;i--)await tap('Previous');await tap('Mark for review');await tap('Review missed cards');
  assert.match(await text('.exam-card'),/Needs review/);await tap('Reset card');await tap('All exam cards');
  await page.reload();await tap('Exam practice');assert.match(await text('.exam-card'),/Not started/);
  await page.goto('file://'+process.cwd()+'/MatrixLab.html');await tap('Study');await $('#guided input').fill('1 2 2');await tap('Check answer');assert.match(await text('#guided'),/Correct\./);
  assert.deepEqual(errors,[]);
  console.log('PASS '+(wk?'WebKit':'Chromium')+' — '+lessons.length+' guided checkpoints, 30 exam checks, study persistence, source presets, row steps, basis, eigenbasis conversion, cofactor controls, Q22, parameter cases, responsive layout and standalone HTML.');
}finally{await browser?.close();await server.close()}
