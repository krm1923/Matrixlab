import test from 'node:test';
import assert from 'node:assert/strict';
import {viewport} from '../src/scene.js';
test('Endpoint drag, two-finger cancellation, and camera-only orbit at tablet sizes',()=>{
 globalThis.ResizeObserver=class {observe(){}};
 globalThis.devicePixelRatio=2;
 globalThis.requestAnimationFrame=fn=>{fn();return 1};
 for(const [width,height] of [[630,580],[834,420]]){
 const ctx=new Proxy({},{get:(o,k)=>o[k]||(()=>{})}),canvas={getContext:()=>ctx,getBoundingClientRect:()=>({width,height,left:0,top:0}),setPointerCapture(){}};
 let changes=0,selections=0,tip=[0,0,0];const v=viewport(canvas,g=>g.arrow(tip,'#00ff00','v',[0,0,0],0,true),{select(){selections++},move(i,p){changes++;tip=p}});
 v.render();const p=(id,x,y)=>({pointerId:id,clientX:width/2+x,clientY:height*.54+y});
 canvas.onpointerdown(p(1,0,0));canvas.onpointermove(p(1,12,0));assert.equal(changes,1);assert.equal(selections,1);
 canvas.onpointerdown(p(2,40,40));canvas.onpointermove(p(2,60,70));canvas.onpointermove(p(1,5,5));assert.equal(changes,1);
 canvas.onpointerup(p(1,5,5));canvas.onpointerup(p(2,60,70));v.opts.drag=false;canvas.onpointerdown(p(1,12,0));canvas.onpointermove(p(1,20,20));assert.equal(changes,1);
 }
});
